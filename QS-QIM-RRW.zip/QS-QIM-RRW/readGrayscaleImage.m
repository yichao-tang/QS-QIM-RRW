function [grayImage, imageInfo] = readGrayscaleImage(filePath)
%READGRAYSCALEIMAGE Read indexed/gray/RGB input as 512-by-512 uint8 gray.

[sourceImage, colorMap] = imread(filePath);
sourceSize = size(sourceImage);

imageInfo = struct();
imageInfo.SourceClass = string(class(sourceImage));
imageInfo.OriginalRows = sourceSize(1);
imageInfo.OriginalCols = sourceSize(2);
if numel(sourceSize) < 3
    imageInfo.OriginalChannels = 1;
else
    imageInfo.OriginalChannels = sourceSize(3);
end

if ~isempty(colorMap)
    rgbImage = ind2rgb(sourceImage, colorMap);
    grayImage = rgb2gray(rgbImage);
    imageInfo.SourceType = "indexed";
    imageInfo.ConversionRule = "indexed palette -> RGB -> grayscale";
elseif ismatrix(sourceImage)
    grayImage = sourceImage;
    imageInfo.SourceType = "grayscale";
    imageInfo.ConversionRule = "grayscale preserved";
elseif size(sourceImage, 3) == 2
    % Some USC-SIPI TIFF files store one grayscale channel plus an extra
    % sample channel. The TIFF metadata still identifies them as grayscale.
    grayImage = sourceImage(:, :, 1);
    imageInfo.SourceType = "grayscale + extra channel";
    imageInfo.ConversionRule = ...
        "first grayscale channel preserved; extra channel ignored";
elseif size(sourceImage, 3) >= 3
    grayImage = rgb2gray(sourceImage(:, :, 1:3));
    imageInfo.SourceType = "RGB";
    imageInfo.ConversionRule = "RGB -> luminance grayscale";
else
    error('readGrayscaleImage:UnsupportedImageShape', ...
        'Unsupported image shape in %s.', filePath);
end

grayImage = convertToUint8(grayImage, filePath);
if size(grayImage, 1) ~= 512 || size(grayImage, 2) ~= 512
    grayImage = imresize(grayImage, [512, 512]);
    imageInfo.ConversionRule = imageInfo.ConversionRule + ...
        "; resized to 512x512";
end
end

function imageOut = convertToUint8(imageIn, filePath)
%CONVERTTOUINT8 Apply a defined intensity conversion for mixed bit depths.

if isa(imageIn, 'uint8')
    imageOut = imageIn;
elseif isa(imageIn, 'uint16') || islogical(imageIn)
    imageOut = im2uint8(imageIn);
elseif isa(imageIn, 'single') || isa(imageIn, 'double')
    values = double(imageIn);
    if any(~isfinite(values(:)))
        error('readGrayscaleImage:NonfiniteImage', ...
            'Image contains NaN or Inf values: %s', filePath);
    end
    minValue = min(values(:));
    maxValue = max(values(:));
    if minValue >= 0 && maxValue <= 1
        imageOut = im2uint8(values);
    elseif minValue >= 0 && maxValue <= 255
        imageOut = uint8(round(values));
    elseif maxValue > minValue
        imageOut = im2uint8(mat2gray(values));
    else
        imageOut = zeros(size(values), 'uint8');
    end
elseif isinteger(imageIn)
    values = double(imageIn);
    minValue = min(values(:));
    maxValue = max(values(:));
    if maxValue > minValue
        imageOut = im2uint8(mat2gray(values));
    else
        imageOut = zeros(size(values), 'uint8');
    end
else
    error('readGrayscaleImage:UnsupportedImageClass', ...
        'Unsupported image class %s in %s.', class(imageIn), filePath);
end
end
