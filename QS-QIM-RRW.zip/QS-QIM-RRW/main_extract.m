clc;
clear;

%% Public extraction parameters must match the embedding parameters
nMax=20; T=100; Delta=34.4; num=128; p_direction='p30_current';
root=fileparts(mfilename('fullpath')); addpath(root);
file_Iw=''; % set to 'attacked_image.png'; empty selects the latest saved image
if isempty(file_Iw), file_Iw=latest_image('I_final.png'); end
check_environment(false);

%% Read without resizing the attacked image
Iw=imread(file_Iw);
validateattributes(Iw,{'uint8'},{'2d','nonempty'});
w_extracted=robust_extract(Iw,nMax,T,Delta,num,p_direction);
disp(w_extracted);
% BER requires the reference watermark for evaluation only; the decoder
% itself does not read the original image or watermark.
