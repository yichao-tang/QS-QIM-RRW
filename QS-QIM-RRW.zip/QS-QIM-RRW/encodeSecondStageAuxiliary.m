function [payload, info] = encodeSecondStageAuxiliary(auxiliary, savedLsb, verifyRoundTrip)
%ENCODESECONDSTAGEAUXILIARY Lossless representation of {d_q,d_c,b_l}.
%   No precision reduction: store both signed components of each d_q.
%   Compare absolute and gap-coded sparse d_c positions; transmit the mode.
%   Format v2: five header bytes [81 83 2 positionMode decimalPlaces],
%   one Arith07 stream with four sequences, then the 256 original LSBs.
%   Benchmarks pass false and perform the round-trip check after timing.
if nargin < 3
    verifyRoundTrip = true;
end

validateattributes(auxiliary.DecimalPlaces, {'numeric'}, ...
    {'scalar', 'integer', '>=', 0, '<=', 9});
validateattributes(auxiliary.QuantizationErrorComplex, {'numeric'}, ...
    {'vector', 'nonempty', 'finite'});
validateattributes(auxiliary.ClippingError, {'numeric'}, ...
    {'2d', 'real', 'finite', 'integer'});
if isfield(auxiliary, 'ReconstructionUsesPaperTruncation') ...
        && ~auxiliary.ReconstructionUsesPaperTruncation
    error('encodeSecondStageAuxiliary:UntruncatedReconstruction', ...
        'Use embedded_main(..., true); do not discard reconstruction precision.');
end
savedLsb = double(savedLsb(:).');
if numel(savedLsb) ~= 256 || any(savedLsb ~= 0 & savedLsb ~= 1)
    error('encodeSecondStageAuxiliary:InvalidLsb', ...
        'Exactly 256 binary original authentication LSBs are required.');
end
scale = 10^auxiliary.DecimalPlaces;
scaledDq = auxiliary.QuantizationErrorComplex(:) * scale;
dqReal = round(real(scaledDq));
dqImag = round(imag(scaledDq));
if any(abs(real(scaledDq) - dqReal) > 1e-7) ...
        || any(abs(imag(scaledDq) - dqImag) > 1e-7)
    error('encodeSecondStageAuxiliary:PrecisionLoss', ...
        'd_q is not already truncated to the stated precision.');
end
positions = find(auxiliary.ClippingError ~= 0);
values = double(auxiliary.ClippingError(positions));
sequences = {dqReal; dqImag; positions; values(:)};
[absoluteBytes, absoluteAccounting] = Arith07(sequences);
sequences{3} = diff([0; positions]);
[gapBytes, gapAccounting] = Arith07(sequences);
positionMode = double(numel(gapBytes) < numel(absoluteBytes));
if positionMode == 1
    codedBytes = gapBytes;
    accounting = gapAccounting;
else
    codedBytes = absoluteBytes;
    accounting = absoluteAccounting;
end
header = [81; 83; 2; positionMode; auxiliary.DecimalPlaces];
bits = dec2bin(uint8([header; codedBytes(:)]), 8).';
payload = [reshape(double(bits) - double('0'), 1, []), savedLsb];

% Validate the standalone decoder, with no untransmitted positions or d_q.
if verifyRoundTrip
    decoded = decodeSecondStageAuxiliary(payload, size(auxiliary.ClippingError));
    if ~isequal(decoded.DqRealIntegers, dqReal) ...
        || ~isequal(decoded.DqImaginaryIntegers, dqImag) ...
        || ~isequal(decoded.ClippingError, double(auxiliary.ClippingError)) ...
        || ~isequal(decoded.SavedLsb, savedLsb)
        error('encodeSecondStageAuxiliary:RoundTripMismatch', ...
            'The lossless auxiliary coding round trip failed.');
    end
end

info = struct();
info.FormatVersion = 2;
info.PositionMode = positionMode;
info.PositionEncoding = "absolute indices";
if positionMode == 1
    info.PositionEncoding = "positive gaps; cumulative sum decoding";
end
info.NumDqComplexValues = numel(dqReal);
info.NumClippedPixels = numel(positions);
info.DqCodingBits = sum(accounting(1:2, 3));
info.DcPositionCodingBits = accounting(3, 3);
info.DcValueCodingBits = accounting(4, 3);
info.ArithmeticFramingBits = 8*numel(codedBytes) - sum(accounting(1:4, 3));
info.PacketHeaderBits = 40;
info.SavedLsbBits = 256;
info.CompressedAuxiliaryBits = 8*numel(codedBytes);
info.PeePayloadBits = numel(payload);
info.LegacyPeePayloadBits = 8*numel(absoluteBytes) + 256;
info.LegacyDqCodingBits = sum(absoluteAccounting(1:2, 3));
info.LegacyDcPositionCodingBits = absoluteAccounting(3, 3);
info.LegacyDcValueCodingBits = absoluteAccounting(4, 3);
info.SavedPayloadBits = info.LegacyPeePayloadBits - info.PeePayloadBits;
info.AbsoluteCandidateBytes = numel(absoluteBytes);
info.GapCandidateBytes = numel(gapBytes);
info.RoundTripVerified = logical(verifyRoundTrip);
end
