function [finalImage, stageInfo] = buildSecondStageFinalImage( ...
        robustImage, embeddingAuxiliaryData, verifyRoundTrip)
%BUILDSECONDSTAGEFINALIMAGE Create I_final for the stage-2 ablation.
%   The auxiliary payload contains the paper-defined truncated PCET moment
%   differences d_q, sparse clipping error d_c, and the saved LSB sequence
%   b_l. The payload is arithmetic-coded and embedded by two-pass PEE-HS.
%   Version 2 selects a lossless sparse-position representation and uses
%   SHA-256 for the 256 authentication LSBs. No d_q/d_c/b_l data is dropped.
%   Benchmarks set verifyRoundTrip=false and verify after the algorithm timer.
if nargin < 3
    verifyRoundTrip = true;
end

validateattributes(robustImage, {'numeric', 'logical'}, ...
    {'2d', 'nonempty', 'real', 'finite'}, mfilename, 'robustImage');
if any(robustImage(:) < 0) || any(robustImage(:) > 255) ...
        || any(robustImage(:) ~= round(robustImage(:)))
    error('buildSecondStageFinalImage:InvalidImage', ...
        'robustImage must contain integer-valued samples in [0,255].');
end
requiredFields = {'DecimalPlaces', 'QuantizationErrorComplex', ...
    'ClippingError'};
if ~isstruct(embeddingAuxiliaryData) ...
        || ~all(isfield(embeddingAuxiliaryData, requiredFields))
    error('buildSecondStageFinalImage:InvalidAuxiliaryData', ...
        'embeddingAuxiliaryData is missing one or more required fields.');
end
if ~isequal(size(embeddingAuxiliaryData.ClippingError), size(robustImage))
    error('buildSecondStageFinalImage:ClippingErrorSizeMismatch', ...
        'ClippingError must have the same size as robustImage.');
end

robustImage = uint8(robustImage);
hashLength = 256;
if numel(robustImage) < hashLength
    error('buildSecondStageFinalImage:ImageTooSmall', ...
        'At least %d pixels are required for authentication.', hashLength);
end
authenticationIndices = 1:hashLength;
savedLsb = double(bitget(robustImage(authenticationIndices), 1));
savedLsb = savedLsb(:).';

[auxiliaryPayload, codingInfo] = encodeSecondStageAuxiliary( ...
    embeddingAuxiliaryData, savedLsb, verifyRoundTrip);

temporaryImage = robustImage;
temporaryImage(authenticationIndices) = bitset( ...
    temporaryImage(authenticationIndices), 1, 0);
[intermediateImage, peeInfo] = reversibleEmbeddingForSecondStage( ...
    temporaryImage, auxiliaryPayload, authenticationIndices);
if ~peeInfo.Success
    error('buildSecondStageFinalImage:PeeEmbeddingFailed', ...
        'PEE-HS could not embed the complete auxiliary payload.');
end
if any(bitget(intermediateImage(authenticationIndices), 1) ~= 0)
    error('buildSecondStageFinalImage:ReservedLsbModified', ...
        'PEE-HS modified one or more reserved authentication pixels.');
end

% Check the actual embedded image, not merely the pre-embedding bitstream.
if verifyRoundTrip
    [restoredTemporaryImage, extractedPayload] = ...
    reversibleDecodingForSecondStage(intermediateImage, authenticationIndices);
    if ~isequal(restoredTemporaryImage, temporaryImage) ...
        || ~isequal(extractedPayload, auxiliaryPayload)
        error('buildSecondStageFinalImage:PeeRoundTripMismatch', ...
            'PEE-HS did not preserve all auxiliary bits and image samples.');
    end
end

authenticationBits = secondStageAuthenticationBits(intermediateImage);
authenticationBits = authenticationBits(:).';
if numel(authenticationBits) ~= hashLength ...
        || any(authenticationBits ~= 0 & authenticationBits ~= 1)
    error('buildSecondStageFinalImage:InvalidAuthenticationHash', ...
        'The authentication function must return exactly 256 binary bits.');
end

finalImage = intermediateImage;
finalImage(authenticationIndices) = bitset( ...
    finalImage(authenticationIndices), 1, authenticationBits);

stageInfo = struct();
stageInfo.Success = true;
stageInfo.AuxiliaryCodingVerified = logical(verifyRoundTrip);
stageInfo.PeeRoundTripVerified = logical(verifyRoundTrip);
stageInfo.HashMethod = "SHA-256, column-major uint8 image bytes";
stageInfo.HashLengthBits = hashLength;
stageInfo.CompressedAuxiliaryBits = codingInfo.CompressedAuxiliaryBits;
stageInfo.AuxiliaryCoding = codingInfo;
stageInfo.SavedLsbBits = numel(savedLsb);
stageInfo.PeePayloadBits = numel(auxiliaryPayload);
stageInfo.TotalSecondStageBits = numel(auxiliaryPayload) + hashLength;
stageInfo.NumQuantizationErrorComplexValues = codingInfo.NumDqComplexValues;
stageInfo.NumClippedPixels = codingInfo.NumClippedPixels;
stageInfo.PeeInfo = peeInfo;
stageInfo.PayloadDefinition = ...
    "v2: full d_q, losslessly coded sparse d_c positions/values, original b_l";
end
