# QS-QIM-RRW

QS-QIM 鲁棒可逆图像水印方案的 MATLAB 实现，包含鲁棒水印嵌入与提取、
PEE-HS 辅助信息嵌入、完整性验证、原图恢复及攻击测试。作者：Yichao Tang。

## 运行

需要 MATLAB R2020a 或更新版本、Image Processing Toolbox 以及启用的 Java。
将 MATLAB 当前文件夹切换到本仓库根目录，首次使用时安装外部算术编码依赖，
然后运行完整流程：

```matlab
setup
main
```

`setup` 安装外部依赖 `Arith07.m`。如果已有该文件，可以使用：

```matlab
installArithmeticCodec('C:\path\to\Arith07.m');
check_environment
```

仓库不附带该第三方文件。

在 `main.m` 开头修改图像路径和参数即可使用自己的图像。
`main_embed.m` 是相同流程的另一入口。默认参数为 128 bit、`nMax = 20`、
`T = 100`、`Delta = 34.4`、`p30_current`（30°）。量化步长决定嵌入失真，
不同图像采用同一量化步长时，PSNR 可以不同。

## 实验入口

| 文件 | 功能 |
|---|---|
| `main.m` / `main_embed.m` | 单图完整两阶段嵌入、提取、恢复及攻击实验 |
| `main_batch.m` | 文件夹批量实验 |
| `main_delta.m` | Δ = 30、32、34、36、38 敏感性实验 |
| `main_direction.m` | 30°、90°、150° 三个合法 QCO 方向实验 |
| `main_extract.m` | 从保存的图像提取鲁棒水印 |
| `main_recover.m` | 从未受攻击的最终水印图像验证完整性并恢复原图 |

运行前修改相应脚本开头的参数。批量实验先稳定排序图像文件，默认以种子 0
抽取至多 100 张；嵌入失败的图像会明确记录，不会自动换图。

攻击参数集中在 `attack_parameters.m`，包括 AWGN、椒盐噪声、JPEG、JPEG2000、
缩放和旋转。启用 `CompareStages` 时，分别对 `Iw1` 与 `I_final` 统计 BER。

## 结果说明

每次运行建立独立结果目录，保存 CSV、XLSX 和 MAT 文件，包括图像质量、
辅助信息长度、各流程耗时和逐图逐攻击 BER，同时保存实际选图与参数。
失败记录包含原因，相关结果保留 `NaN`，汇总表报告有效样本数。

输入图像预处理为 512×512 的 `uint8` 灰度图；“原图精确恢复”指恢复该预处理
图像。需要恢复时，将 `I_final` 保存为无损 PNG 或 BMP。攻击后的测试指标为
鲁棒水印 BER，不代表受攻击图像仍可无损恢复。

辅助码流由矩量化误差、裁剪补偿、原始 LSB 及编码封装组成。
另行写入的 256 bit SHA-256 摘要不计入辅助码流长度。

核心步骤在根目录的 `QS_QIM_version.m`、`embedded_main.m`、
`robust_extract.m`、`reversible_embedding.m` 与 `reversible_decoding.m` 中。
安装依赖后可以运行 `results = runtests('tests');` 执行自动化检查。

## 许可与引用

原创项目代码采用 MIT 许可证，外部依赖仍按各自条款使用，不包含在该许可中。
软件引用信息见 `CITATION.cff`，完整英文说明见 `README.md`。
