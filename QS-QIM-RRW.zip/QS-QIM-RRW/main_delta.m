clc;
clear;

%% Parameters setting
Delta_values = [30 32 34 36 38];
nMax = 20;
T = 100;
seed_num = 0;
num_images = 100;

%% Images reading (one fixed sample for every Delta)
root = fileparts(mfilename('fullpath'));
addpath(root);
image_folder = fullfile(root,'image'); % change to the dataset folder
p=experiment_parameters();
p.nMax=nMax; p.T=T; p.WatermarkSeed=seed_num; p.NumImages=num_images;
p.SaveImages=false;
files=select_images(image_folder,num_images,p.SelectionSeed);
parent=fullfile(root,'results','delta');
if ~isfolder(parent), mkdir(parent); end
sweepFolder=tempname(parent); mkdir(sweepFolder);
allResults=cell(numel(Delta_values),1);
for k=1:numel(Delta_values)
    p.Delta=Delta_values(k);
    allResults{k}=run_experiments(files,p,sweepFolder);
end
summary=vertcatResults(allResults);
writetable(summary,fullfile(sweepFolder,'delta_summary.csv'));
save(fullfile(sweepFolder,'delta_results.mat'),'allResults','Delta_values');
disp(summary);

function summary=vertcatResults(results)
tables=cellfun(@(x) x.Summary,results,'UniformOutput',false);
summary=vertcat(tables{:});
end
