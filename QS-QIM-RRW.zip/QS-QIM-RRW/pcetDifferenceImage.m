function differenceImage = pcetDifferenceImage(imageSize, nMax, dq)
%PCETDIFFERENCEIMAGE Shared paper d_q synthesis for embedding and recovery.
%   No original image or untransmitted moment coordinates are required.
[layout, selected] = pcetMomentLayout(nMax);
dq = dq(:).';
if numel(dq) > numel(selected)
    error('pcetDifferenceImage:InvalidMomentCount', ...
        'N is too small for the supplied d_q count.');
end
selected = selected(1:numel(dq));
differences = complex(zeros(4, size(layout, 1)));
differences(1:3, :) = layout.';
differences(4, selected) = dq;
[found, conjugatePositions] = ismember(-layout(selected, 2:3), ...
    layout(:, 2:3), 'rows');
if ~all(found)
    error('pcetDifferenceImage:MissingConjugate', 'Missing conjugate moments.');
end
differences(4, conjugatePositions) = conj(dq);
differenceImage = real(PCET_reconstruct_func(imageSize, differences));
end
