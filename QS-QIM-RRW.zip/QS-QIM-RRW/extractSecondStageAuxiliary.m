function [robustImage, auxiliary] = extractSecondStageAuxiliary(finalImage)
%EXTRACTSECONDSTAGEAUXILIARY Authenticate and undo PEE-HS on an intact image.
validateattributes(finalImage, {'uint8'}, {'2d', 'nonempty'});
if size(finalImage, 1) ~= size(finalImage, 2) || numel(finalImage) < 256
    error('recoverSecondStageImage:InvalidImage', ...
        'A square image with at least 256 pixels is required.');
end
indices = 1:256;
storedHash = double(bitget(finalImage(indices), 1));
intermediate = finalImage;
intermediate(indices) = bitset(intermediate(indices), 1, 0);
if ~isequal(storedHash(:).', secondStageAuthenticationBits(intermediate))
    error('recoverSecondStageImage:AuthenticationFailed', ...
        'The final image failed SHA-256 verification.');
end
[temporaryImage, payload] = reversibleDecodingForSecondStage(intermediate, indices);
auxiliary = decodeSecondStageAuxiliary(payload, size(finalImage));
robustImage = temporaryImage;
robustImage(indices) = bitset(robustImage(indices), 1, auxiliary.SavedLsb);
end
