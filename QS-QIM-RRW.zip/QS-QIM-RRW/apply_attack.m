function attacked = apply_attack(Iw, type, value, seed)
%APPLY_ATTACK Apply one independent attack using a reproducible random field.
%   Scaling is direct; rotation uses nearest interpolation and crop/zero fill.
validateattributes(Iw,{'uint8'},{'2d','nonempty'});
validateattributes(value,{'numeric'},{'scalar','real','finite'});
validateattributes(seed,{'numeric'},{'scalar','integer','nonnegative','<=',2^32-1});
savedRng = rng;
restoreRng = onCleanup(@() rng(savedRng)); %#ok<NASGU>
rng(seed,'twister');
switch char(type)
    case 'NoAttack'
        attacked = Iw;
    case 'AWGN'
        validateattributes(value,{'numeric'},{'>=',0,'<=',1});
        attacked = imnoise(Iw,'gaussian',0,value);
    case 'SP'
        validateattributes(value,{'numeric'},{'>=',0,'<=',1});
        attacked = imnoise(Iw,'salt & pepper',value);
    case {'JPEG','JPEG2000'}
        if strcmp(type,'JPEG')
            validateattributes(value,{'numeric'},{'integer','>=',0,'<=',100});
            file = [tempname,'.jpg'];
            cleanup = onCleanup(@() removeTemporary(file)); %#ok<NASGU>
            imwrite(Iw,file,'jpg','Quality',value);
        else
            validateattributes(value,{'numeric'},{'>=',1});
            file = [tempname,'.jp2'];
            cleanup = onCleanup(@() removeTemporary(file)); %#ok<NASGU>
            imwrite(Iw,file,'jp2','CompressionRatio',value);
        end
        attacked = imread(file);
    case 'Scaling'
        validateattributes(value,{'numeric'},{'positive'});
        side = max(2,2*round(size(Iw,1)*value/2));
        attacked = imresize(Iw,[side side],'nearest');
    case 'Rotation'
        attacked = imrotate(Iw,value,'nearest','crop');
    otherwise
        error('QSQIM:UnknownAttack','Unknown attack type: %s.',char(type));
end
end

function removeTemporary(file)
if exist(file,'file')==2, delete(file); end
end
