function summary = summarize_results(ber, quality, p, numRequested)
%SUMMARIZE_RESULTS Report sample coverage alongside every aggregate BER.
stages=unique(ber.Stage,'stable');
rows=cell(numel(stages)*height(p.Attacks),13);
n=0;
for j=1:numel(stages)
    for k=1:height(p.Attacks)
        n=n+1;
        take=ber.Stage==stages(j) & ber.Condition==p.Attacks.Condition(k);
        group=ber(take,:);
        good=group.Status=="ok";
        numCompleted=nnz(good);
        bitErrors=NaN; rate=NaN;
        if numCompleted>0
            bitErrors=sum(group.BitErrors(good));
            rate=bitErrors/(p.num*numCompleted);
        end
        rows(n,:)={p.Delta,string(p.Direction),stages(j),p.Attacks.Condition(k), ...
            numRequested,nnz(quality.Status=="ok"),numCompleted, ...
            numRequested-numCompleted,numCompleted*p.num,bitErrors,rate,100*rate, ...
            numCompleted==numRequested};
    end
end
summary=cell2table(rows,'VariableNames',{'Delta','Direction','Stage','Condition', ...
    'NumImagesRequested','NumEmbedded','NumImagesCompleted','NumMissingOrFailed', ...
    'NumBits','BitErrors','BER','BER_Percent','CompleteSample'});
end
