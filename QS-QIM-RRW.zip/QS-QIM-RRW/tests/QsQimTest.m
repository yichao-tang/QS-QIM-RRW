classdef QsQimTest < matlab.unittest.TestCase
    %QSQIMTEST Public-interface regressions for the complete watermark scheme.
    % A deterministic synthetic image avoids redistributing test photographs.

    properties (SetAccess = private)
        Parameters
        Original
        Watermark
        Result
        Images
        RecoveredIw1
        ExtractedFinal
        ScaledImage
        ScaledBits
    end

    methods (TestClassSetup)
        function prepareCompleteExperiment(testCase)
            root = fileparts(fileparts(mfilename('fullpath')));
            originalPath = path;
            testCase.addTeardown(@() path(originalPath));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(root));
            check_environment();

            p = experiment_parameters();
            p.NumImages = 1;
            p.CompareStages = true;
            p.SaveImages = false;
            p.SaveAttackedImages = false;
            p.ExportExcel = false;
            p.Attacks = table( ...
                ["NoAttack"; "AWGN_0.025"; "JPEG_10"; "JPEG2000_100"; ...
                 "SP_0.025"; "Scaling_0.5"; "Rotation_30"], ...
                ["NoAttack"; "AWGN"; "JPEG"; "JPEG2000"; ...
                 "SP"; "Scaling"; "Rotation"], ...
                [0; 0.025; 10; 100; 0.025; 0.5; 30], ...
                'VariableNames', {'Condition', 'Type', 'Value'});

            testCase.Parameters = p;
            testCase.Original = QsQimTest.makeImage();
            testCase.Watermark = repmat([0 1], 1, 64);
            [testCase.Result, testCase.Images] = QS_QIM_version( ...
                testCase.Original, p.nMax, p.T, p.Delta, ...
                testCase.Watermark, p);
            [~, testCase.RecoveredIw1] = reversible_decoding( ...
                testCase.Images.I_final, p.nMax);
            testCase.ExtractedFinal = robust_extract( ...
                testCase.Images.I_final, p.nMax, p.T, p.Delta, ...
                p.num, p.Direction);
            testCase.ScaledImage = apply_attack( ...
                testCase.Images.I_final, 'Scaling', 0.5, 101);
            testCase.ScaledBits = robust_extract( ...
                testCase.ScaledImage, p.nMax, p.T, p.Delta, ...
                p.num, p.Direction);
        end
    end

    methods (Test)
        function recoversOriginalImageExactly(testCase)
            testCase.verifyTrue(testCase.Result.ExactRecovery);
            testCase.verifyEqual(testCase.Images.I_recovered, testCase.Original);
        end

        function recoversFirstStageImageExactly(testCase)
            testCase.verifyEqual(testCase.RecoveredIw1, testCase.Images.Iw1);
        end

        function intactExtractionReturnsBinaryWatermark(testCase)
            testCase.verifySize(testCase.ExtractedFinal, [1 128]);
            testCase.verifyTrue(all( ...
                testCase.ExtractedFinal == 0 | testCase.ExtractedFinal == 1));
        end

        function noAttackBerMatchesPublicExtraction(testCase)
            rows = testCase.Result.AttackResults;
            measuredBer = nnz(testCase.ExtractedFinal ~= testCase.Watermark) / 128;
            testCase.verifyEqual(testCase.Result.BER_no_attack, ...
                measuredBer, 'AbsTol', eps);
            testCase.verifyEqual(rows.BER(rows.Condition == "NoAttack"), ...
                [testCase.Result.BER_no_attack_Iw1; ...
                 testCase.Result.BER_no_attack], 'AbsTol', eps);
        end

        function runsBothStagesUnderEveryConfiguredAttack(testCase)
            rows = testCase.Result.AttackResults;
            testCase.verifySize(rows, [14 10]);
            testCase.verifyEqual(rows.Status, repmat("ok", 14, 1));
            testCase.verifyEqual(rows.AttackSeed(rows.Stage == "Iw1"), ...
                rows.AttackSeed(rows.Stage == "I_final"), 'AbsTol', 0);
        end

        function attackBitErrorsAndBerHaveValidRanges(testCase)
            rows = testCase.Result.AttackResults;
            testCase.verifyTrue(all(rows.BitErrors >= 0 & rows.BitErrors <= 128));
            testCase.verifyEqual(rows.BitErrors, round(rows.BitErrors), 'AbsTol', 0);
            testCase.verifyEqual(rows.BER, rows.BitErrors / 128, 'AbsTol', eps);
            testCase.verifyEqual(rows.BER_Percent, 100 * rows.BER, 'AbsTol', eps);
        end

        function extractsFromEvenSizedScaledImage(testCase)
            testCase.verifySize(testCase.ScaledImage, [256 256]);
            testCase.verifySize(testCase.ScaledBits, [1 128]);
            testCase.verifyTrue(all(testCase.ScaledBits == 0 | testCase.ScaledBits == 1));
        end

        function rejectsTamperedImageDuringRecovery(testCase)
            tampered = testCase.Images.I_final;
            tampered(1) = bitxor(tampered(1), uint8(1));
            testCase.verifyError(@() reversible_decoding( ...
                tampered, testCase.Parameters.nMax), ...
                'recoverSecondStageImage:AuthenticationFailed');
        end

        function rejectsRectangularExtractionInput(testCase)
            p = testCase.Parameters;
            testCase.verifyError(@() robust_extract( ...
                zeros(512, 510, 'uint8'), p.nMax, p.T, p.Delta, p.num), ...
                'QSQIM:ImageSize');
        end

        function rejectsOddSidedExtractionInput(testCase)
            p = testCase.Parameters;
            testCase.verifyError(@() robust_extract( ...
                zeros(511, 511, 'uint8'), p.nMax, p.T, p.Delta, p.num), ...
                'QSQIM:ImageSize');
        end

        function rejectsUnsupportedWatermarkLength(testCase)
            p = testCase.Parameters;
            p.num = 127;
            testCase.verifyError(@() validate_experiment(p), 'QSQIM:WatermarkLength');
        end

        function attackPreservesCallerRandomState(testCase)
            callerState = rng;
            testCase.addTeardown(@() rng(callerState));
            attacked = apply_attack(testCase.Images.I_final, 'AWGN', 0.025, 73);
            testCase.verifyEqual(rng, callerState);
            testCase.verifySize(attacked, size(testCase.Images.I_final));
        end

        function pairedIdenticalInputsReceiveIdenticalNoise(testCase)
            first = apply_attack(testCase.Images.I_final, 'AWGN', 0.025, 91);
            second = apply_attack(testCase.Images.I_final, 'AWGN', 0.025, 91);
            testCase.verifyEqual(first, second);
        end
    end

    methods (Static, Access = private)
        function image = makeImage()
            surface = peaks(512);
            normalized = (surface - min(surface(:))) / ...
                (max(surface(:)) - min(surface(:)));
            image = uint8(round(32 + 192 * normalized));
        end
    end
end
