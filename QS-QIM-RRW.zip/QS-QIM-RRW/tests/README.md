# Verification

Run `check_environment` after setup to check MATLAB, the required toolbox,
Java, and the external arithmetic codec.

The complete experiment checks no-attack watermark extraction, reversible
auxiliary extraction, digest verification, and exact recovery of the prepared
input image. It records failures explicitly alongside the successful results.

Run the automated regression checks from the repository root:

```matlab
results = runtests('tests');
assert(all([results.Passed]));
```

Generated test results are not part of the source distribution.
