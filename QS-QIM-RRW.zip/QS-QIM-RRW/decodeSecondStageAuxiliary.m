function auxiliary = decodeSecondStageAuxiliary(payload, imageSize)
%DECODESECONDSTAGEAUXILIARY Decode version-2 {d_q,d_c,b_l} without side data.
%   Image dimensions are provided by the received/restored image itself.

payload = double(payload(:).');
validateattributes(imageSize, {'numeric'}, ...
    {'vector', 'numel', 2, 'integer', 'positive'});
if numel(payload) < 304 || mod(numel(payload) - 256, 8) ~= 0 ...
        || any(payload ~= 0 & payload ~= 1)
    error('decodeSecondStageAuxiliary:InvalidPacket', ...
        'The auxiliary packet has invalid length or nonbinary samples.');
end
bytes = reshape(payload(1:end-256), 8, []).' * (2.^(7:-1:0)).';
if ~isequal(bytes(1:3), [81; 83; 2]) ...
        || ~ismember(bytes(4), [0, 1]) || bytes(5) > 9
    error('decodeSecondStageAuxiliary:InvalidHeader', ...
        'Unsupported auxiliary format, position mode, or precision.');
end
sequences = Arith07(bytes(6:end));
if numel(sequences) ~= 4
    error('decodeSecondStageAuxiliary:InvalidSequences', ...
        'Expected exactly four arithmetic-coded sequences.');
end
dqReal = sequences{1}(:);
dqImag = sequences{2}(:);
positions = sequences{3}(:);
values = sequences{4}(:);
if bytes(4) == 1
    positions = cumsum(positions);
end
if isempty(dqReal) || numel(dqReal) ~= numel(dqImag) ...
        || numel(positions) ~= numel(values) ...
        || any(positions < 1 | positions > prod(imageSize)) ...
        || any(diff(positions) <= 0) || any(values == 0)
    error('decodeSecondStageAuxiliary:InvalidSequences', ...
        'Invalid d_q components or sparse clipping-error coordinates.');
end
auxiliary = struct();
auxiliary.DecimalPlaces = bytes(5);
auxiliary.DqRealIntegers = dqReal;
auxiliary.DqImaginaryIntegers = dqImag;
auxiliary.QuantizationErrorComplex = complex(dqReal, dqImag) / 10^bytes(5);
auxiliary.ClippingError = zeros(imageSize);
auxiliary.ClippingError(positions) = values;
auxiliary.SavedLsb = payload(end-255:end);
end
