# Third-party dependency

## Arithmetic coding: Arith07

The reversible auxiliary-information stream uses Karl Skretting's `Arith07`
arithmetic codec. Its original source carries this notice:

> Copyright (c) 1999-2001. Karl Skretting. All rights reserved.

Author's source and documentation:
https://www.ux.uis.no/~karlsk/proj99/index.html

MATLAB Central listing:
https://www.mathworks.com/matlabcentral/fileexchange/2818-huffman-coding-and-arithmetic-coding

The MATLAB Central listing states **No License** (checked 15 October 2026).
The GitHub source distribution therefore does not contain `Arith07.m`.
The author's archive can be obtained independently, or downloaded directly
from the author's server by explicitly running `installArithmeticCodec`.
This project does not grant a license to that separately obtained file.

The installer checks the author's archive and codec against pinned SHA-256
values, preserves the author's notice, adds the byte-buffer growth fix used
by the research implementation, and disables progress printing. The coding
model, arithmetic operations and stream format are retained. Installation
includes a known-byte compatibility check and a large-integer round trip.

`third_party/arith07/` contains the locally installed dependency and must be
excluded from commits and public archives. The helper also accepts the
verified research copy through `installArithmeticCodec('/path/Arith07.m')`.

### Verified versions

| Item | SHA-256 |
| --- | --- |
| Author's `comp.zip` | `b931aeb0639bdff9835c5b0fc4055218990e88a461ce8be5520915f10d375596` |
| Original `Arith07.m` | `6de80f5975fc53c05c27476477da50111264688927ee88dbbfaeaba37bf33592` |
| Research `Arith07.m` before installation | `6ddbc0f90de1d2ac43e19ad178efbc74308db9d245df3f18cdcd9028a46349ee` |

## Runtime

MATLAB and Image Processing Toolbox are separately licensed MathWorks
products and are not distributed with this repository. SHA-256 uses the
Java runtime provided with MATLAB. No pretrained models are required.
