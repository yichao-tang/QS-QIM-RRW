function qx = spheredecodetoMLwi(x, wi, Delta, directionName)
%SPHEREDECODETOMLWI Find the nearest codeword carrying bit wi.
%   Delta scales the fine-lattice generator and must match the value used
%   by the embedder and extractor. DIRECTIONNAME selects a legal QCO
%   direction and defaults to the historical p30_current direction.

if nargin < 3 || isempty(Delta)
    Delta = getTi();
end
if nargin < 4 || isempty(directionName)
    directionName = "p30_current";
end

[H, J, d, Gc] = getPa(Delta, directionName);
[~, ~, dist_min] = spheredecodetoML(x, d, H, J);
d = 2 * (dist_min + d);
[~, m] = size(H);
[Q, R] = qr(H);

k = m;
s = R \ (Q' * x);
sk_k1(m) = s(m);
di(m) = sqrt(d^2 - norm(x)^2 + norm(H * s)^2);
dist_min = Inf;

flag = 0;
res_z = zeros(1, k);
highBound = zeros(1, m);
lowBound = zeros(1, m);
z = zeros(1, m);
while flag == 0
    [highBound(k), lowBound(k)] = BoundsZk(di, R, sk_k1, k);
    z(k) = lowBound(k);
    flag = 1;
    while flag == 1
        z(k) = z(k) + 1;
        if z(k) <= highBound(k)
            if k == 1
                candidate_distance = norm(H * z' - x);
                Ai = getAiByZ(z, Gc, J);
                if mod(Ai, 2) == wi && candidate_distance <= dist_min ...
                        && isempty(find(H * z' < 0, 1))
                    res_z = z;
                    dist_min = candidate_distance;
                end
                flag = 1;
            else
                k = k - 1;
                offset = 0;
                for j = k + 1:m
                    offset = offset + (R(k, j) / R(k, k)) ...
                        * (z(j) - s(j));
                end
                sk_k1(k) = s(k) - offset;
                di(k) = sqrt(di(k + 1)^2 - R(k + 1, k + 1)^2 ...
                    * (z(k + 1) - sk_k1(k + 1))^2);
                flag = 0;
            end
        else
            k = k + 1;
            if k == m + 1
                flag = -1;
                break;
            end
        end
    end
end

qx = H * res_z';
end
