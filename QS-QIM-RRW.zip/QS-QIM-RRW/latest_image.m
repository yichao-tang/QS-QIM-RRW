function file = latest_image(imageName)
%LATEST_IMAGE Locate a saved image from the most recent experiment.
root=fileparts(mfilename('fullpath'));
files=dir(fullfile(root,'results','**',imageName));
assert(~isempty(files),'QSQIM:NoSavedImage', ...
    'Run main first, or specify your own image filename in this script.');
[~,k]=max([files.datenum]);
file=fullfile(files(k).folder,files(k).name);
end
