function w = robust_extract(Iw, nMax, T, Delta, num, direction)
%ROBUST_EXTRACT Extract robust bits without the original image or watermark.
%   Square, even-sized attacked images are accepted without rescaling.
if nargin < 6, direction = 'p30_current'; end
if nargin < 5, num = 128; end
validateattributes(Iw, {'uint8'}, {'2d','nonempty'});
assert(size(Iw,1)==size(Iw,2) && mod(size(Iw,1),2)==0, ...
    'QSQIM:ImageSize','Extraction requires a square image with even sides.');
validateattributes(nMax, {'numeric'}, {'scalar','integer','positive'});
validateattributes(T, {'numeric'}, {'scalar','real','finite','positive'});
validateattributes(Delta, {'numeric'}, {'scalar','real','finite','positive'});
validateattributes(num, {'numeric'}, {'scalar','integer','positive'});

%% Calculate the same ordered PCET carriers as at embedding
[~,selected,sourceIndices] = pcetMomentLayout(nMax);
assert(2*num<=numel(selected), 'QSQIM:MomentCount', ...
    'nMax is too small for the requested watermark length.');
indices = sourceIndices(selected(1:2*num));
MMT = PCET_func(Iw,nMax,indices,false);
s = reshape(abs(MMT(3,indices)*T),2,[]);

%% Original nearest-lattice QS-QIM decision
[H,J,d] = getPa(Delta,direction);
w = zeros(1,num);
for k = 1:num
    [~,w(k)] = spheredecodetoML(s(:,k),d,H,J);
end
end
