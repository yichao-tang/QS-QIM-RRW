function [I, Iw1, auxiliary] = reversible_decoding(I_final, nMax)
%REVERSIBLE_DECODING Verify the digest and exactly restore an intact image.
[I,Iw1,auxiliary] = recoverSecondStageImage(I_final,nMax);
end
