# Arithmetic-code dependency

Run `setup` from the repository root once. This obtains the author's
verified Arith07 source and installs it locally in `arith07/`.

For an offline installation, use a separately obtained verified source:

```matlab
installArithmeticCodec('/path/to/Arith07.m');
check_environment;
```

The installed file stays on the user's machine and is ignored by Git.
Do not add it to this repository's source archive. Its copyright and
license information is documented in `../THIRD_PARTY_NOTICES.md`.
