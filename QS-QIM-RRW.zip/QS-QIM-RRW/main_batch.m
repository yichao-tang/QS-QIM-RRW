clc;
clear;

%% Parameters setting
nMax = 20;
T = 100;
Delta = 34.4;
num = 128;
seed_num = 0;
num_images = 100;
selection_seed = 0;
p_direction = 'p30_current';

%% Dataset setting
root = fileparts(mfilename('fullpath'));
addpath(root);
image_folder = fullfile(root,'image');
% image_folder = fullfile(root,'data','SIPI');
% image_folder = fullfile(root,'data','BOWS2');
% Use an explicit saved list to reproduce a particular paper sample:
% image_folder = {'/path/to/first.pgm'; '/path/to/second.pgm'};

%% Two-stage embedding, recovery, timing, overhead and attacks
p = experiment_parameters();
p.nMax=nMax; p.T=T; p.Delta=Delta; p.num=num;
p.WatermarkSeed=seed_num; p.SelectionSeed=selection_seed;
p.Direction=p_direction; p.NumImages=num_images;
p.CompareStages=true;
results=run_experiments(image_folder,p,fullfile(root,'results'));
disp(results.Summary);
