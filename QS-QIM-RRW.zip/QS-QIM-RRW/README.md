# QS-QIM-RRW

MATLAB implementation of the QS-QIM robust reversible image watermarking
scheme. The code includes robust watermark embedding and extraction,
PEE-HS auxiliary information embedding, integrity verification, original
image recovery, and robustness experiments.

Originally written by Yichao Tang.

## Requirements

- MATLAB R2020a or later with Image Processing Toolbox and Java enabled.
- The external arithmetic codec `Arith07.m`, installed using `setup`.

## Run the algorithm

Download this repository and change MATLAB's current folder to its root.
Run the setup once, then run the complete single-image experiment:

```matlab
setup
main
```

The `main.m` script contains the image path and algorithm parameters at the
top. It runs both embedding stages, extracts the robust watermark, verifies
the digest, recovers the original image, and tests the configured attacks.
`main_embed.m` is an alternative entry to the same experiment.

If the codec is already available locally, install it without downloading:

```matlab
installArithmeticCodec('C:\path\to\Arith07.m');
check_environment
```

The codec is an external dependency and is not distributed with this repository.

The default setting uses a 128-bit watermark, `nMax = 20`, `T = 100`,
`Delta = 34.4`, and QCO direction `p30_current` (30 degrees). The quantization
step controls embedding distortion; the same `Delta` does not imply the
same PSNR on different images.

## Experiment scripts

Edit the parameters at the beginning of the corresponding script and run:

| Script | Experiment |
|---|---|
| `main` or `main_embed` | Complete single-image algorithm and robustness tests |
| `main_batch` | Batch experiment on images in a selected folder |
| `main_delta` | Quantization steps `[30, 32, 34, 36, 38]` |
| `main_direction` | Legal QCO directions `p30_current`, `p90`, and `p150` |
| `main_extract` | Robust watermark extraction from a saved image |
| `main_recover` | Integrity verification and recovery from an intact final image |

The batch script starts with a stable sorted image list and uses selection
seed 0 when sampling at most 100 images. It does not replace images after
embedding failures. Each run saves the actual image selection and parameters.

The attack settings are defined in `attack_parameters.m`: AWGN, salt-and-pepper
noise, JPEG, JPEG2000, scaling, and rotation. `CompareStages` enables paired
results for the robust watermarked image `Iw1` and the final image `I_final`.

## Results

Each experiment creates its own output directory. CSV, XLSX, and MAT files
record image quality, auxiliary information overhead, runtime, and BER.
`cost_summary.csv` reports measured means, sample standard deviations and
ranges with the number of valid images. The four timers exclude image
preparation, disk I/O, attack generation and additional round-trip checks.
Per-image robustness results use one row per image, parameter setting,
watermarking stage, and attack condition. BER is recorded together with its
condition rather than relying on column position.

Embedding failures are recorded with their reason and `NaN` results. Summary
tables include the number of successful images; failed images are not
silently reported as zero BER. The saved images and MAT files support
subsequent extraction, recovery, and reproducibility.

Input reading converts supported RGB or indexed images to grayscale and
resizes them to 512-by-512 `uint8`. Exact recovery refers to this prepared
grayscale image. Save `I_final` losslessly as PNG or BMP for reversible
recovery. Robust extraction is evaluated separately on attacked images.

## Code organization

`QS_QIM_version.m` runs the complete single-image workflow. The main algorithm
functions are `embedded_main.m`, `robust_extract.m`,
`reversible_embedding.m`, and `reversible_decoding.m`. The PCET, lattice,
entropy coding, and PEE-HS helpers are readable MATLAB files in the root
directory. `experiment_parameters.m`, `run_experiments.m`,
`attack_parameters.m`, and `apply_attack.m` implement the experiment workflow.

For use from another MATLAB program:

```matlab
p = experiment_parameters();
p.Delta = 34.4;
experiment = run_experiments('C:\path\to\images', p, 'results');
```

The authentication sequence is a separately embedded 256-bit SHA-256 digest.
It is excluded from the reported auxiliary bitstream length. Recovery is
performed from the intact final image; the attack experiments measure robust
watermark extraction rather than lossless recovery after an attack.

The SHA-256 digest is unkeyed. PEE-HS prioritizes pixels outside the
inscribed disk and uses interior candidates when additional capacity is
needed. The distributed example images are procedural test inputs rather
than the photographs used in the paper. The paper's table values require
its corresponding image list, parameters and experimental protocol.

After setup, run the automated checks with:

```matlab
results = runtests('tests');
assert(all([results.Passed]));
```

## License and citation

Original project code is released under the MIT License. External
dependencies are excluded from that grant and retain their own terms.
See `LICENSE` and the dependency information in `third_party/`.

Software citation metadata is provided in `CITATION.cff`.

The associated manuscript is *A Two-Stage Robust Reversible Image
Watermarking Scheme Using 2D Lattice QIM With Quantization Strips*, by
Yichao Tang, Zhuangxi Yao, Yingxi Huang, Chuntao Wang, and Shijun Xiang.

Related implementations by the author:
[FrPCET-RRW](https://github.com/yichao-tang/FrPCET-RRW),
[STDM-RRW](https://github.com/yichao-tang/STDM-RRW), and
[PZMs-RRW](https://github.com/yichao-tang/PZMs-RRW).
