function [watermarkedImage, embeddingInfo] = ...
        reversibleEmbeddingForSecondStage(image, payloadBits, ...
        excludedLinearIndices)
%REVERSIBLEEMBEDDINGFORSECONDSTAGE PEE-HS embedding for the ablation study.
%   This is an experiment-safe variant of the repository's
%   reversible_embedding function. It preserves the original two-pass X/O
%   checkerboard PEE-HS algorithm and excludes authentication pixels.
%   Prefer the outside region; extend inside the PCET incircle if necessary.
%   Decode with reversibleDecodingForSecondStage (not the legacy decoder).

if nargin < 3 || isempty(excludedLinearIndices)
    excludedLinearIndices = [];
end

validateattributes(image, {'numeric', 'logical'}, ...
    {'2d', 'nonempty', 'real', 'finite'}, mfilename, 'image');
if any(image(:) < 0) || any(image(:) > 255) ...
        || any(image(:) ~= round(image(:)))
    error('reversibleEmbeddingForSecondStage:InvalidImage', ...
        'The input image must contain integer-valued samples in [0,255].');
end
if mod(size(image, 1), 2) ~= 0 || mod(size(image, 2), 2) ~= 0
    error('reversibleEmbeddingForSecondStage:OddImageSize', ...
        'The PEE-HS implementation requires even image dimensions.');
end

payloadBits = double(payloadBits(:).');
if isempty(payloadBits) || any(payloadBits ~= 0 & payloadBits ~= 1)
    error('reversibleEmbeddingForSecondStage:InvalidPayload', ...
        'payloadBits must be a nonempty binary vector.');
end

if ~isempty(excludedLinearIndices)
    validateattributes(excludedLinearIndices, {'numeric'}, ...
        {'vector', 'integer', 'positive', '<=', numel(image)}, ...
        mfilename, 'excludedLinearIndices');
end
excludedMask = false(size(image));
excludedMask(excludedLinearIndices) = true;

splitIndex = round(numel(payloadBits) / 2);
if splitIndex >= 2^20
    error('reversibleEmbeddingForSecondStage:PayloadTooLong', ...
        'Each pass payload length must fit in the 20-bit header.');
end
[afterCross, crossInfo] = embedCheckerboardPass(double(image), ...
    payloadBits(1:splitIndex), 1, excludedMask);
[watermarkedImage, dotInfo] = embedCheckerboardPass(afterCross, ...
    payloadBits(splitIndex + 1:end), 2, excludedMask);

watermarkedImage = uint8(watermarkedImage);
embeddingInfo = struct();
embeddingInfo.Success = crossInfo.Success && dotInfo.Success;
embeddingInfo.PayloadBits = numel(payloadBits);
embeddingInfo.CrossPayloadBits = splitIndex;
embeddingInfo.DotPayloadBits = numel(payloadBits) - splitIndex;
embeddingInfo.CrossUsedFraction = crossInfo.UsedFraction;
embeddingInfo.DotUsedFraction = dotInfo.UsedFraction;
embeddingInfo.CrossNegativeThreshold = crossInfo.NegativeThreshold;
embeddingInfo.CrossPositiveThreshold = crossInfo.PositiveThreshold;
embeddingInfo.DotNegativeThreshold = dotInfo.NegativeThreshold;
embeddingInfo.DotPositiveThreshold = dotInfo.PositiveThreshold;
embeddingInfo.NumExcludedPixels = nnz(excludedMask);
embeddingInfo.CrossUsedInside = crossInfo.UsedInside;
embeddingInfo.DotUsedInside = dotInfo.UsedInside;
embeddingInfo.NumInsidePixelsChanged = crossInfo.NumInsidePixelsChanged ...
    + dotInfo.NumInsidePixelsChanged;
embeddingInfo.RegionPolicy = ...
    "outside first; inside fallback; authentication pixels excluded";
end

function [imageOut, passInfo] = embedCheckerboardPass(imageIn, payload, ...
        checkerboardType, excludedMask)
%EMBEDCHECKERBOARDPASS Embed one half of the payload into one pixel set.

[predictedImage, sortedErrors, coordinates, numOutside] = ...
    secondStagePeeCandidates(imageIn, checkerboardType, excludedMask);
try
    [imageOut, passInfo] = embedCandidateSequence(imageIn, payload, ...
        predictedImage, sortedErrors(1:numOutside), ...
        coordinates(1:numOutside, :));
catch exception
    if ~ismember(exception.identifier, { ...
            'reversibleEmbeddingForSecondStage:InsufficientCandidates', ...
            'reversibleEmbeddingForSecondStage:InsufficientCapacity'})
        rethrow(exception);
    end
    [imageOut, passInfo] = embedCandidateSequence(imageIn, payload, ...
        predictedImage, sortedErrors, coordinates);
end
passInfo.UsedInside = passInfo.LastUsedIndex > numOutside;
insideCoordinates = coordinates(numOutside + 1:end, :);
insideIndices = sub2ind(size(imageIn), insideCoordinates(:, 1), ...
    insideCoordinates(:, 2));
passInfo.NumInsidePixelsChanged = ...
    nnz(imageOut(insideIndices) ~= imageIn(insideIndices));
end

function [imageOut, passInfo] = embedCandidateSequence(imageIn, payload, ...
        predictedImage, sortedErrors, sequenceToRowColumn)
%EMBEDCANDIDATESEQUENCE Preserve the original PEE-HS and 34-bit header.

imageOut = imageIn;
payloadAndHeaderLength = numel(payload) + 34;
% Reserve 34 header pixels AND embed their 34 original LSBs in the message.
if numel(sortedErrors) - 34 < payloadAndHeaderLength
    error('reversibleEmbeddingForSecondStage:InsufficientCandidates', ...
        'Only %d candidates are available; at least %d are required.', ...
        numel(sortedErrors), numel(payload) + 68);
end

savedLsb = zeros(1, 34);
for index = 1:34
    row = sequenceToRowColumn(index, 1);
    column = sequenceToRowColumn(index, 2);
    savedLsb(index) = bitget(uint8(imageOut(row, column)), 1);
end

negativeThreshold = 0;
positiveThreshold = 0;
histogramCounts = hist(sortedErrors(35:end), -255:255); %#ok<HIST>
while sum(histogramCounts(double(negativeThreshold) + 256: ...
        double(positiveThreshold) + 256)) < payloadAndHeaderLength
    if abs(negativeThreshold) <= positiveThreshold
        negativeThreshold = negativeThreshold - 1;
    else
        positiveThreshold = positiveThreshold + 1;
    end
    if negativeThreshold < -127 || positiveThreshold > 127
        error('reversibleEmbeddingForSecondStage:InsufficientCapacity', ...
            'The requested payload exceeds the available PEE-HS capacity.');
    end
end

locationMap = zeros(3, numel(sortedErrors));
embeddable = zeros(2, max(numel(sortedErrors) - 34, 1));
numEmbeddable = 0;
numProcessed = 0;
numLocationMap = 0;
usedFraction = NaN;

while numProcessed < payloadAndHeaderLength + numLocationMap
    for index = 35:numel(sortedErrors)
        row = sequenceToRowColumn(index, 1);
        column = sequenceToRowColumn(index, 2);
        [numModifications, embeddingOrShift] = modificationCapacity( ...
            predictedImage(row, column), sortedErrors(index), ...
            negativeThreshold, positiveThreshold);
        if numModifications == 2
            numEmbeddable = numEmbeddable + 1;
            embeddable(1, numEmbeddable) = index;
            embeddable(2, numEmbeddable) = embeddingOrShift;
            if embeddingOrShift == 1
                numProcessed = numProcessed + 1;
            end
        else
            numLocationMap = numLocationMap + 1;
            locationMap(1, numLocationMap) = index;
            locationMap(2, numLocationMap) = numModifications;
            locationMap(3, numLocationMap) = embeddingOrShift;
        end

        if numProcessed == payloadAndHeaderLength + numLocationMap
            usedFraction = index / numel(sortedErrors);
            break
        end
    end

    if numProcessed ~= payloadAndHeaderLength + numLocationMap
        if abs(negativeThreshold) <= positiveThreshold
            negativeThreshold = negativeThreshold - 1;
        else
            positiveThreshold = positiveThreshold + 1;
        end
        if negativeThreshold < -127 || positiveThreshold > 127
            error('reversibleEmbeddingForSecondStage:InsufficientCapacity', ...
                'The requested payload cannot be embedded without overflow.');
        end
        numEmbeddable = 0;
        numProcessed = 0;
        numLocationMap = 0;
    end
end

message = [locationMap(2, 1:numLocationMap), payload, savedLsb];
messageIndex = 0;
for index = 1:numEmbeddable
    sortedIndex = embeddable(1, index);
    predictionError = sortedErrors(sortedIndex);
    if embeddable(2, index) == 1
        messageIndex = messageIndex + 1;
        predictionError = predictionError * 2 + message(messageIndex);
    elseif predictionError < 0
        predictionError = predictionError + negativeThreshold;
    else
        predictionError = predictionError + positiveThreshold + 1;
    end
    row = sequenceToRowColumn(sortedIndex, 1);
    column = sequenceToRowColumn(sortedIndex, 2);
    imageOut(row, column) = predictedImage(row, column) + predictionError;
end

if messageIndex ~= numel(message)
    error('reversibleEmbeddingForSecondStage:IncompleteEmbedding', ...
        'Only %d of %d message bits were embedded.', ...
        messageIndex, numel(message));
end

for index = 1:numLocationMap
    sortedIndex = locationMap(1, index);
    predictionError = sortedErrors(sortedIndex);
    if locationMap(2, index) == 1
        if locationMap(3, index) == 1
            if predictionError < 0
                predictionError = predictionError * 2;
            else
                predictionError = predictionError * 2 + 1;
            end
        elseif predictionError < 0
            predictionError = predictionError + negativeThreshold;
        else
            predictionError = predictionError + positiveThreshold + 1;
        end
    end
    row = sequenceToRowColumn(sortedIndex, 1);
    column = sequenceToRowColumn(sortedIndex, 2);
    imageOut(row, column) = predictedImage(row, column) + predictionError;
end

headerBits = [unsignedIntegerToBits(uint16(abs(negativeThreshold)), 7), ...
    unsignedIntegerToBits(uint16(positiveThreshold), 7), ...
    unsignedIntegerToBits(uint32(numel(payload)), 20)];
for index = 1:34
    row = sequenceToRowColumn(index, 1);
    column = sequenceToRowColumn(index, 2);
    imageOut(row, column) = bitset(uint8(imageOut(row, column)), ...
        1, headerBits(index));
end

passInfo = struct();
passInfo.Success = true;
passInfo.UsedFraction = usedFraction;
passInfo.NegativeThreshold = double(negativeThreshold);
passInfo.PositiveThreshold = double(positiveThreshold);
passInfo.LastUsedIndex = round(usedFraction * numel(sortedErrors));
end

function bits = unsignedIntegerToBits(value, numBits)
%UNSIGNEDINTEGERTOBITS Match the LSB-first header format of the old code.

bits = zeros(1, numBits);
for index = 1:numBits
    bits(index) = bitget(value, index);
end
end

function [numModifications, embeddingOrShift] = modificationCapacity( ...
        prediction, predictionError, negativeThreshold, positiveThreshold)
%MODIFICATIONCAPACITY Determine whether a pixel supports two modifications.

numModifications = 0;
embeddingOrShift = 1;
if predictionError >= 0 && predictionError <= positiveThreshold
    firstModifiedError = predictionError * 2 + 1;
    if prediction + firstModifiedError <= 255
        numModifications = 1;
        if firstModifiedError <= positiveThreshold
            secondModifiedError = firstModifiedError * 2 + 1;
        else
            secondModifiedError = firstModifiedError + positiveThreshold + 1;
        end
        if prediction + secondModifiedError <= 255
            numModifications = 2;
        end
    end
elseif predictionError < 0 && predictionError >= negativeThreshold
    firstModifiedError = predictionError * 2;
    if prediction + firstModifiedError >= 0
        numModifications = 1;
        if firstModifiedError >= negativeThreshold
            secondModifiedError = firstModifiedError * 2;
        else
            secondModifiedError = firstModifiedError + negativeThreshold;
        end
        if prediction + secondModifiedError >= 0
            numModifications = 2;
        end
    end
elseif predictionError >= 0
    embeddingOrShift = 2;
    firstModifiedError = predictionError + positiveThreshold + 1;
    if prediction + firstModifiedError <= 255
        numModifications = 1;
        secondModifiedError = firstModifiedError + positiveThreshold + 1;
        if prediction + secondModifiedError <= 255
            numModifications = 2;
        end
    end
else
    embeddingOrShift = 2;
    firstModifiedError = predictionError + negativeThreshold;
    if prediction + firstModifiedError >= 0
        numModifications = 1;
        secondModifiedError = firstModifiedError + negativeThreshold;
        if prediction + secondModifiedError >= 0
            numModifications = 2;
        end
    end
end
end
