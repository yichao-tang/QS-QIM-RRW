function codecPath = installArithmeticCodec(sourceFile, destinationFolder)
%INSTALLARITHMETICCODEC Obtain and verify the external Arith07 dependency.
%   INSTALLARITHMETICCODEC downloads Karl Skretting's original archive from
%   the author's university website. Run this explicitly during setup.
%
%   INSTALLARITHMETICCODEC(FILE) uses an independently obtained Arith07.m.
%   Both the published original and this project's verified research copy
%   are accepted. No third-party implementation is included in this repo.
%
%   PATH = INSTALLARITHMETICCODEC(FILE, FOLDER) chooses the local installation
%   folder. The default is third_party/arith07 below this setup file.
%
%   The installed copy retains the author's notice. A byte-buffer growth
%   fix prevents overflow for large integer streams without changing the
%   coding model or encoded bytes. Progress printing is disabled.

if nargin < 1
    sourceFile = '';
end
if nargin < 2 || isempty(destinationFolder)
    destinationFolder = fullfile(fileparts(mfilename('fullpath')), ...
        'third_party', 'arith07');
end
sourceFile = char(sourceFile);
destinationFolder = char(destinationFolder);
codecPath = fullfile(destinationFolder, 'Arith07.m');
upstreamHash = '6de80f5975fc53c05c27476477da50111264688927ee88dbbfaeaba37bf33592';
researchHash = '6ddbc0f90de1d2ac43e19ad178efbc74308db9d245df3f18cdcd9028a46349ee';
archiveHash = 'b931aeb0639bdff9835c5b0fc4055218990e88a461ce8be5520915f10d375596';
installedHashes = { ...
    'a491d7127bc8a8008f5bb3563ea56e6f85368c7a4c4f8371f85276157fc1cf41', ...
    'd887196e5c03aca3de8f66f799a8f22a138c25f72c4c3591b447e96164f3a219'};

if isfile(codecPath)
    if ~ismember(fileSha256(codecPath), installedHashes)
        error('QSQIM:UnrecognizedInstalledCodec', ...
            ['An unrecognized Arith07.m already exists at the installation ', ...
             'path. It has not been overwritten: %s'], codecPath);
    end
    verifyCodecFolder(destinationFolder);
    fprintf('Arith07 is installed and verified: %s\n', codecPath);
    return;
end

temporaryFolder = [tempname, '_qsqim_codec'];
mkdir(temporaryFolder);
temporaryCleanup = onCleanup(@() removeTemporaryFolder(temporaryFolder)); %#ok<NASGU>
if isempty(sourceFile)
    sourceUrl = 'https://www.ux.uis.no/~karlsk/proj99/comp.zip';
    fprintf('Downloading the external arithmetic codec from its author...\n');
    archivePath = fullfile(temporaryFolder, 'comp.zip');
    websave(archivePath, sourceUrl, weboptions('Timeout', 60));
    if ~strcmp(fileSha256(archivePath), archiveHash)
        error('QSQIM:CodecArchiveChanged', ...
            ['The author archive differs from the verified version. ', ...
             'No dependency was installed. Download and review it manually.']);
    end
    % The pinned archive contains only files at its top level.
    archiveFile = java.util.zip.ZipFile(archivePath);
    archiveCleanup = onCleanup(@() archiveFile.close());
    archiveEntries = archiveFile.entries();
    while archiveEntries.hasMoreElements()
        entry = archiveEntries.nextElement();
        entryName = char(entry.getName());
        if contains(entryName, '/') || contains(entryName, char(92)) ...
                || contains(entryName, ':') || strcmp(entryName, '..')
            error('QSQIM:UnsafeCodecArchive', ...
                'Unexpected path in the verified codec archive.');
        end
    end
    clear archiveCleanup;
    unzip(archivePath, temporaryFolder);
    sourceFile = fullfile(temporaryFolder, 'Arith07.m');
elseif ~isfile(sourceFile)
    error('QSQIM:CodecFileNotFound', 'Arith07.m was not found: %s', sourceFile);
end

sourceHash = fileSha256(sourceFile);
if ~strcmp(sourceHash, upstreamHash) && ~strcmp(sourceHash, researchHash)
    error('QSQIM:UnrecognizedCodec', ...
        ['The supplied codec is not a verified Arith07 version. ', ...
         'No dependency was installed. SHA-256: %s'], sourceHash);
end

sourceText = fileread(sourceFile);
sourceText = strrep(sourceText, sprintf('\r\n'), sprintf('\n'));
sourceText = strrep(sourceText, sprintf('\r'), sprintf('\n'));
sourceText = regexprep(sourceText, '(?m)^Display=1;[^\n]*', ...
    'Display=0;      % suppress progress printing during experiments');
if ~contains(sourceText, 'newCapacity = max(Byte, max(1024, 2*numel(y)))')
    writeStatement = 'y(Byte) = bitset(y(Byte),BitPos,Bit);';
    if numel(strfind(sourceText, writeStatement)) ~= 1 %#ok<STREMP>
        error('QSQIM:CodecPatchMismatch', ...
            'Cannot identify the verified buffer-write location.');
    end
    bufferFix = sprintf(['%% QS-QIM: grow the byte buffer without changing encoded bits.\n', ...
        'if Byte > numel(y)\n', ...
        '   newCapacity = max(Byte, max(1024, 2*numel(y)));\n', ...
        '   y(newCapacity,1) = 0;\n', ...
        'end\n', ...
        '%s'], writeStatement);
    sourceText = strrep(sourceText, writeStatement, bufferFix);
end

verifiedFolder = fullfile(temporaryFolder, 'verified');
mkdir(verifiedFolder);
verifiedFile = fullfile(verifiedFolder, 'Arith07.m');
fileId = fopen(verifiedFile, 'wb');
if fileId < 0
    error('QSQIM:CodecWriteFailed', 'Cannot write the temporary codec.');
end
fileCleanup = onCleanup(@() fclose(fileId));
fwrite(fileId, unicode2native(sourceText, 'UTF-8'), 'uint8');
clear fileCleanup;
verifyCodecFolder(verifiedFolder);
if ~isfolder(destinationFolder)
    mkdir(destinationFolder);
end
copyfile(verifiedFile, codecPath);
fprintf('Arith07 was installed and verified: %s\n', codecPath);
fprintf('This local dependency is excluded from the GitHub source archive.\n');
end

function verifyCodecFolder(codecFolder)
originalFolder = pwd;
originalPath = path;
globalState = captureCodecGlobals();
restoreState = onCleanup(@() restoreMatlabState( ...
    originalFolder, originalPath, globalState)); %#ok<NASGU>
cd(codecFolder);
addpath(pwd, '-begin');
clear Arith07;
expectedFile = fullfile(pwd, 'Arith07.m');
if ~strcmpi(which('Arith07'), expectedFile)
    error('QSQIM:CodecPathConflict', 'MATLAB selected another Arith07.m.');
end
sequences = {[0; 1; 1; 0; 1]; [12; -7; 0; 19]; []};
expectedBytes = [241; 101; 57; 57; 241; 31; 225; 29; 216; 0];
encoded = Arith07(sequences);
if ~isequal(encoded, expectedBytes) || ~isequal(Arith07(encoded), sequences)
    error('QSQIM:CodecVerificationFailed', ...
        'The installed codec failed the known-byte compatibility check.');
end
stream = RandStream('mt19937ar', 'Seed', 7);
largeIntegers = randi(stream, [2^28, 2^30], 2000, 1);
encoded = Arith07({largeIntegers});
decoded = Arith07(encoded);
if ~isequal(decoded{1}, largeIntegers)
    error('QSQIM:CodecVerificationFailed', ...
        'The installed codec failed the buffer-growth round-trip check.');
end
clear Arith07;
end

function restoreMatlabState(originalFolder, originalPath, globalState)
cd(originalFolder);
path(originalPath);
clear Arith07;
names = fieldnames(globalState);
for index = 1:numel(names)
    name = names{index};
    previous = globalState.(name);
    if previous.Existed
        eval(['global ', name]);
        eval([name, ' = previous.Value;']);
    else
        eval(['clear global ', name]);
    end
end
end

function state = captureCodecGlobals()
% Preserve globals owned by an already-running caller of the old codec.
names = {'y', 'Byte', 'BitPos', 'high', 'low', 'range', 'ub', ...
    'hc', 'lc', 'sc', 'K', 'code'};
existingNames = who('global');
state = struct();
for index = 1:numel(names)
    name = names{index};
    previous = struct('Existed', ismember(name, existingNames), 'Value', []);
    if previous.Existed
        eval(['global ', name]);
        previous.Value = eval(name);
    end
    state.(name) = previous;
end
end

function digest = fileSha256(filePath)
fileId = fopen(filePath, 'rb');
if fileId < 0
    error('QSQIM:CodecReadFailed', 'Cannot read file: %s', filePath);
end
fileCleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
bytes = fread(fileId, Inf, '*uint8');
hasher = java.security.MessageDigest.getInstance('SHA-256');
hasher.update(typecast(bytes(:), 'int8'));
digestBytes = typecast(hasher.digest(), 'uint8');
digest = lower(reshape(dec2hex(digestBytes, 2).', 1, []));
end

function removeTemporaryFolder(temporaryFolder)
% Only remove the exact directory generated by this installer invocation.
[~, temporaryName] = fileparts(temporaryFolder);
if isfolder(temporaryFolder) && endsWith(temporaryName, '_qsqim_codec')
    rmdir(temporaryFolder, 's');
end
end
