function [img_pe,img_err,err_sorted,seq_map] = sortErrWithSur(img,xo)
%SORTERRWITHSUR Vectorized original checkerboard predictor and variance order.
%   Enumerate candidates in the exact historical i/j/two-pixel order; stable
%   smoothness ties must be identical for reversible decoding.
[r,c] = size(img);
img = double(img);
if xo == 1
    offset = [0,0;1,1];
else
    offset = [1,0;0,1];
end
[j,i] = ndgrid(1:round(c/2)-1, 1:round(r/2)-1);
first = sub2ind([r,c], 2*i(:)+offset(1,1), 2*j(:)+offset(1,2));
second = sub2ind([r,c], 2*i(:)+offset(2,1), 2*j(:)+offset(2,2));
indices = reshape([first.'; second.'], [], 1);
surround = [img(indices-r), img(indices-1), img(indices+r), img(indices+1)];
prediction = round(mean(surround,2));
errors = img(indices)-prediction;
distances = abs(diff(surround(:,[1 2 3 4 1]),1,2));
smoothness = var(distances,0,2);
[~, order] = sort(smoothness);
img_pe = zeros(r,c);
img_err = zeros(r,c);
seq_map = repmat(r*c,r,c);
img_pe(indices) = prediction;
img_err(indices) = errors;
err_sorted = reshape(errors(order),1,[]);
seq_map(indices(order)) = 1:numel(indices);
end
