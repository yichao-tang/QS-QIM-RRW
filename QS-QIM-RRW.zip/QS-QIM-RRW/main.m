clc;
clear;

%% Parameters setting
nMax = 20;                  % maximum PCET order
T = 100;                    % carrier normalization scale
Delta = 34.4;               % QS-QIM quantization step
num = 128;                  % watermark length
seed_num = 0;               % watermark seed
p_direction = 'p30_current'; % QCO direction

%% Images reading
root = fileparts(mfilename('fullpath'));
addpath(root);
image_file = fullfile(root,'image','example.png');
% image_file = 'your_image.png';

%% Complete algorithm and robustness evaluation
p = experiment_parameters();
p.nMax = nMax;
p.T = T;
p.Delta = Delta;
p.num = num;
p.Direction = p_direction;
p.WatermarkSeed = seed_num;
p.NumImages = 1;
p.CompareStages = true;      % paired Iw1 / I_final comparison
p.Attacks = attack_parameters(); % edit strengths in attack_parameters.m
results = run_experiments(image_file,p,fullfile(root,'results'));

%% Results in the workspace and in CSV / Excel / MAT files
psnr_Iw1 = results.ImageQuality.PSNR_Iw1_dB;
psnr_Ifinal = results.ImageQuality.PSNR_Ifinal_dB;
BER_no_attack = results.ImageQuality.NoAttackBER_Ifinal;
BER_robust = results.BER;
disp(results.Summary(:,{'Stage','Condition','NumImagesCompleted','BER_Percent'}));
