function check_environment(requireCodec)
%CHECK_ENVIRONMENT Check dependencies before starting an experiment.
if nargin < 1, requireCodec = true; end
assert(~verLessThan('matlab','9.8'),'QSQIM:MatlabVersion', ...
    'MATLAB R2020a or later is required.');
assert(~isempty(ver('images')) && license('test','image_toolbox'), ...
    'QSQIM:Toolbox','Image Processing Toolbox is required.');
assert(usejava('jvm'),'QSQIM:JVM','Start MATLAB with the JVM enabled.');
root = fileparts(mfilename('fullpath'));
codecFolder = fullfile(root,'third_party','arith07');
if exist(fullfile(codecFolder,'Arith07.m'),'file')==2
    addpath(codecFolder);
end
if requireCodec
    assert(exist('Arith07','file')==2,'QSQIM:MissingCodec', ...
        'Run setup once to install the separately distributed Arith07 dependency.');
end
end
