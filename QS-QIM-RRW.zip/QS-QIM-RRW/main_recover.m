clc;
clear;

%% Input must be an intact, losslessly saved final image
nMax=20;
root=fileparts(mfilename('fullpath')); addpath(root);
file_Ifinal=''; % set to your final PNG; empty selects the latest saved image
if isempty(file_Ifinal), file_Ifinal=latest_image('I_final.png'); end
check_environment();
I_final=imread(file_Ifinal);
validateattributes(I_final,{'uint8'},{'size',[512 512]});

%% Digest verification and exact recovery; no resampling
[I_recovered,Iw1_recovered,auxiliary]=reversible_decoding(I_final,nMax);
outputRoot=fullfile(root,'results');
if ~isfolder(outputRoot), mkdir(outputRoot); end
outputFolder=tempname(outputRoot); mkdir(outputFolder);
imwrite(I_recovered,fullfile(outputFolder,'I_recovered.png'));
imwrite(Iw1_recovered,fullfile(outputFolder,'Iw1_recovered.png'));
fprintf('Verified and recovered: %s\n',outputFolder);
