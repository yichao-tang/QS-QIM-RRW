function [I_final, info] = reversible_embedding(Iw1, auxiliary)
%REVERSIBLE_EMBEDDING Embed complete auxiliary information and the digest.
%   Diagnostics are performed by the caller after the algorithm timer.
[I_final,info] = buildSecondStageFinalImage(Iw1,auxiliary,false);
end
