function [I, info] = prepare_image(file)
%PREPARE_IMAGE Convert a user-supplied image to 512x512 uint8 grayscale.
%   Recovery targets this prepared image, not the original file bytes.
[I,info] = readGrayscaleImage(char(file));
end
