function [result, images] = QS_QIM_version(I, nMax, T, Delta, w, options)
%QS_QIM_VERSION Complete two-stage QS-QIM embedding, extraction and recovery.
%   Return algorithm timings, overhead and paired Iw1/I_final attack BER.
%   Image preparation and all diagnostics are outside the algorithm timers.
if nargin < 6, options = experiment_parameters(); end
options.nMax=nMax; options.T=T; options.Delta=Delta;
validate_experiment(options);
check_environment();
validateattributes(I,{'uint8'},{'size',[512 512]});
validateattributes(w,{'numeric','logical'},{'vector','binary','numel',128});
w=double(w(:).');

%% Robust watermark embedding
timer=tic;
[Iw1,auxiliary]=embedded_main(I,nMax,T,Delta,w,options.Direction);
time_embed=toc(timer);

%% Auxiliary information and hash embedding
timer=tic;
[I_final,stage]=reversible_embedding(Iw1,auxiliary);
time_reversible=toc(timer);

%% Robust watermark extraction from the complete final image
timer=tic;
w_final=robust_extract(I_final,nMax,T,Delta,numel(w),options.Direction);
time_extract=toc(timer);

%% Integrity verification and original-image recovery
timer=tic;
[I_recovered,Iw1_recovered,decoded]=reversible_decoding(I_final,nMax);
time_recover=toc(timer);

%% Verification and statistics (outside the four timing intervals)
assert(isequal(I_recovered,I) && isequal(Iw1_recovered,Iw1), ...
    'QSQIM:RecoveryMismatch','Recovery did not reproduce the prepared input.');
assert(isequal(decoded.QuantizationErrorComplex(:),auxiliary.QuantizationErrorComplex(:)) ...
    && isequal(decoded.ClippingError,auxiliary.ClippingError), ...
    'QSQIM:AuxiliaryMismatch','Recovered auxiliary values do not match.');
stage.AuxiliaryCodingVerified=true;
stage.PeeRoundTripVerified=true;
stage.AuxiliaryCoding.RoundTripVerified=true;
w_first=robust_extract(Iw1,nMax,T,Delta,numel(w),options.Direction);
result=struct('PSNR_Iw1',psnr(Iw1,I),'PSNR_Ifinal',psnr(I_final,I), ...
    'BER_no_attack_Iw1',nnz(w_first~=w)/numel(w), ...
    'BER_no_attack',nnz(w_final~=w)/numel(w), ...
    'ExactRecovery',true,'Watermark',w,'Parameters',options, ...
    'StageInfo',stage,'Timing',struct('RobustEmbedding',time_embed, ...
    'ReversibleEmbedding',time_reversible,'WatermarkExtraction',time_extract, ...
    'VerificationAndRecovery',time_recover));
images=struct('I',I,'Iw1',Iw1,'I_final',I_final,'I_recovered',I_recovered);

%% Independent attacks with paired random realizations
stages="I_final";
if options.CompareStages, stages=["Iw1","I_final"]; end
attackRows=cell(height(options.Attacks)*numel(stages),10);
row=0;
for k=1:height(options.Attacks)
    condition=options.Attacks(k,:);
    for j=1:numel(stages)
        row=row+1;
        status="ok"; message=""; bitErrors=NaN; ber=NaN;
        attackSeed=options.AttackSeed+k;
        try
            if condition.Type=="NoAttack"
                if stages(j)=="Iw1", extracted=w_first; else, extracted=w_final; end
            else
                attacked=apply_attack(images.(char(stages(j))), ...
                    condition.Type,condition.Value,attackSeed);
                extracted=robust_extract(attacked,nMax,T,Delta,numel(w),options.Direction);
                if options.SaveAttackedImages && isfield(options,'ImageOutputFolder')
                    imwrite(attacked,fullfile(options.ImageOutputFolder, ...
                        [char(stages(j)),'_',char(condition.Condition),'.png']));
                end
            end
            bitErrors=nnz(extracted~=w);
            ber=bitErrors/numel(w);
        catch failure
            status="attack_failed"; message=string(failure.message);
        end
        attackRows(row,:)={stages(j),condition.Condition,condition.Type, ...
            condition.Value,attackSeed,bitErrors,ber,ber*100,status,message};
    end
end
result.AttackResults=cell2table(attackRows,'VariableNames', ...
    {'Stage','Condition','AttackType','AttackValue','AttackSeed','BitErrors', ...
    'BER','BER_Percent','Status','ErrorMessage'});
end
