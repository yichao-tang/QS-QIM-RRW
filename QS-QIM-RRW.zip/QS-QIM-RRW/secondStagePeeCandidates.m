function [predictedImage, sortedErrors, coordinates, numOutside] = ...
        secondStagePeeCandidates(image, checkerboardType, excludedMask)
%SECONDSTAGEPEECANDIDATES Shared, reversible outside-first pixel ordering.
%   Within each region retain sortErrWithSur's smoothness order. The order
%   depends only on the OTHER checkerboard set, so decoding can reproduce it.

[numRows, numCols] = size(image);
[predictedImage, ~, sortedErrors, sequenceMap] = ...
    sortErrWithSur(double(image), checkerboardType);
[x, y] = meshgrid(linspace(-1, 1, numCols), linspace(-1, 1, numRows));
inside = x.^2 + y.^2 <= 1;
coordinates = zeros(numel(sortedErrors), 2);
isInside = false(numel(sortedErrors), 1);
pixels = find(sequenceMap ~= numRows*numCols & ~excludedMask);
sequenceIndices = sequenceMap(pixels);
[rows, columns] = ind2sub([numRows,numCols], pixels);
coordinates(sequenceIndices,:) = [rows, columns];
isInside(sequenceIndices) = inside(pixels);
valid = coordinates(:, 1) ~= 0;
outsideIndices = find(valid & ~isInside);
insideIndices = find(valid & isInside);
order = [outsideIndices; insideIndices];
coordinates = coordinates(order, :);
sortedErrors = double(reshape(sortedErrors(order), 1, []));
numOutside = numel(outsideIndices);
end
