function [restoredImage, payloadBits] = ...
        reversibleDecodingForSecondStage(image, excludedLinearIndices)
%REVERSIBLEDECODINGFORSECONDSTAGE Invert outside-first two-pass PEE-HS.
%   Input is the PEE-HS image BEFORE authentication LSBs are inserted.
%   For I_final, first clear the known authentication LSBs. Supply the same
%   excluded indices as the encoder. This is a lossless/no-attack check,
%   not a replacement for the robust QS-QIM watermark decoder.

if nargin < 2
    excludedLinearIndices = [];
end
validateattributes(image, {'numeric', 'logical'}, ...
    {'2d', 'nonempty', 'real', 'finite', 'integer', '>=', 0, '<=', 255});
if any(mod(size(image), 2) ~= 0)
    error('reversibleDecodingForSecondStage:OddImageSize', ...
        'The PEE-HS implementation requires even image dimensions.');
end
if ~isempty(excludedLinearIndices)
    validateattributes(excludedLinearIndices, {'numeric'}, ...
        {'vector', 'integer', 'positive', '<=', numel(image)});
end
excludedMask = false(size(image));
excludedMask(excludedLinearIndices) = true;
[afterDot, dotPayload] = decodePass(double(image), 2, excludedMask);
[restoredImage, crossPayload] = decodePass(afterDot, 1, excludedMask);
restoredImage = uint8(restoredImage);
payloadBits = [crossPayload, dotPayload];
end

function [imageOut, payload] = decodePass(imageIn, checkerboard, excludedMask)
[prediction, errors, coordinates] = ...
    secondStagePeeCandidates(imageIn, checkerboard, excludedMask);
numCandidates = numel(errors);
if numCandidates < 68
    error('reversibleDecodingForSecondStage:InvalidHeader', ...
        'There are too few candidates for a PEE-HS header.');
end
linearIndices = sub2ind(size(imageIn), coordinates(:, 1), coordinates(:, 2));
header = double(bitget(uint8(imageIn(linearIndices(1:34))), 1));
negativeThreshold = -sum(header(1:7).' .* 2.^(0:6));
positiveThreshold = sum(header(8:14).' .* 2.^(0:6));
payloadLength = sum(header(15:34).' .* 2.^(0:19));
if payloadLength + 68 > numCandidates
    error('reversibleDecodingForSecondStage:InvalidHeader', ...
        'The PEE-HS header requests more bits than the candidate count.');
end
message = zeros(1, numCandidates);
locationIndices = zeros(1, numCandidates);
locationIsEmbedding = false(1, numCandidates);
numBits = 0;
numLocations = 0;
lastIndex = 34;
while numBits < payloadLength + 34 + numLocations
    lastIndex = lastIndex + 1;
    if lastIndex > numCandidates
        error('reversibleDecodingForSecondStage:IncompletePayload', ...
            'The complete PEE-HS payload could not be extracted.');
    end
    predictionError = errors(lastIndex);
    predictedPixel = prediction(linearIndices(lastIndex));
    isEmbedding = predictionError >= 2 * negativeThreshold ...
        && predictionError <= 2 * positiveThreshold + 1;
    if predictionError >= 0 && predictionError <= positiveThreshold
        canModify = predictedPixel + 2 * predictionError + 1 <= 255;
    elseif predictionError < 0 && predictionError >= negativeThreshold
        canModify = predictedPixel + 2 * predictionError >= 0;
    elseif predictionError > positiveThreshold
        canModify = predictedPixel + predictionError + positiveThreshold + 1 <= 255;
    else
        canModify = predictedPixel + predictionError + negativeThreshold >= 0;
    end
    if canModify
        if isEmbedding
            numBits = numBits + 1;
            message(numBits) = mod(predictionError, 2);
        end
        errors(lastIndex) = undoModification(predictionError, ...
            isEmbedding, negativeThreshold, positiveThreshold);
    else
        numLocations = numLocations + 1;
        locationIndices(numLocations) = lastIndex;
        locationIsEmbedding(numLocations) = isEmbedding;
    end
end
for index = 1:numLocations
    if message(index) ~= 0
        location = locationIndices(index);
        errors(location) = undoModification(errors(location), ...
            locationIsEmbedding(index), negativeThreshold, positiveThreshold);
    end
end
payload = message(numLocations + 1:numBits - 34);
savedLsb = message(numBits - 33:numBits);
imageOut = imageIn;
imageOut(linearIndices(1:34)) = bitset( ...
    uint8(imageOut(linearIndices(1:34))), 1, savedLsb(:));
imageOut(linearIndices(35:lastIndex)) = ...
    prediction(linearIndices(35:lastIndex)) + errors(35:lastIndex).';
if any(imageOut(:) < 0 | imageOut(:) > 255)
    error('reversibleDecodingForSecondStage:InvalidRestoration', ...
        'PEE-HS decoding produced out-of-range pixels.');
end
end

function predictionError = undoModification(predictionError, ...
        isEmbedding, negativeThreshold, positiveThreshold)
if isEmbedding
    predictionError = floor(predictionError / 2);
elseif predictionError >= 0
    predictionError = predictionError - positiveThreshold - 1;
else
    predictionError = predictionError - negativeThreshold;
end
end
