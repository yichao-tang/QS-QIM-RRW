function ti = getTi()
%GETTI Return the legacy default QS-QIM quantization step.
%   New experiment code passes Delta explicitly; this default is retained
%   only for backward compatibility with older callers.

ti = 34.5;
end
