% MAIN_EMBED Run the complete single-image embedding and extraction experiment.
% The parameter block is in main.m, following the earlier RRW repositories.
main;
