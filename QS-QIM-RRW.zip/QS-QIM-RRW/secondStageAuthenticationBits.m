function bits = secondStageAuthenticationBits(image)
%SECONDSTAGEAUTHENTICATIONBITS SHA-256 of column-major uint8 image bytes.
%   For verification clear the 256 reserved LSBs before calling this helper.
validateattributes(image, {'uint8'}, {'2d', 'nonempty'});
digest = javaMethod('getInstance', 'java.security.MessageDigest', 'SHA-256');
digest.update(typecast(image(:), 'int8'));
bytes = typecast(digest.digest(), 'uint8');
characters = dec2bin(bytes(:), 8).';
bits = reshape(double(characters) - double('0'), 1, []);
end
