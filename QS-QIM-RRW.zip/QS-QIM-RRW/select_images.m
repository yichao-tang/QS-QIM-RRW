function files = select_images(imageInput, numImages, seed)
%SELECT_IMAGES Select a reproducible sample without quality-based filtering.
%   A folder is scanned nonrecursively. Explicit file lists keep their order.
validateattributes(numImages,{'numeric'},{'scalar','integer','positive'});
if iscell(imageInput) || (isstring(imageInput)&&~isscalar(imageInput))
    files=cellstr(string(imageInput(:)));
    assert(~isempty(files),'QSQIM:NoImages','The image list is empty.');
    assert(all(cellfun(@(f) exist(f,'file')==2,files)), ...
        'QSQIM:MissingImage','One or more specified image files do not exist.');
    files=files(1:min(numImages,numel(files)));
elseif isfolder(char(imageInput))
    folder=char(imageInput);
    candidates=dir(folder);
    candidates=candidates(~[candidates.isdir]);
    supported={'.png','.bmp','.tif','.tiff','.jpg','.jpeg','.gif','.pgm'};
    keep=false(numel(candidates),1);
    for k=1:numel(candidates)
        [~,~,extension]=fileparts(candidates(k).name);
        keep(k)=ismember(lower(extension),supported);
    end
    candidates=candidates(keep);
    assert(~isempty(candidates),'QSQIM:NoImages','No supported images found in %s.',folder);
    [~,order]=sort(lower(string({candidates.name})));
    candidates=candidates(order);
    if numel(candidates)>numImages
        savedRng=rng;
        restoreRng=onCleanup(@() rng(savedRng)); %#ok<NASGU>
        rng(seed,'twister');
        candidates=candidates(randperm(numel(candidates),numImages));
    end
    files=arrayfun(@(f) fullfile(f.folder,f.name),candidates(:),'UniformOutput',false);
elseif isfile(char(imageInput))
    files={char(imageInput)};
else
    error('QSQIM:MissingImage','Image file or folder not found: %s.',char(imageInput));
end
end
