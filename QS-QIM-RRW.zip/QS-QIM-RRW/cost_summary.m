function summary = cost_summary(quality)
%COST_SUMMARY Aggregate measured overhead and algorithm execution time.
%   Statistics use successful images and sample standard deviation (N-1).
metrics={'DqBits','DcBits','BlBits','HeaderAndCodingBits','AuxiliaryBits', ...
    'HashBits','TotalSecondStageBits','RobustEmbedding_s','ReversibleEmbedding_s', ...
    'WatermarkExtraction_s','VerificationAndRecovery_s'};
units=[repmat("bits",7,1);repmat("seconds",4,1)];
rows=cell(numel(metrics),8);
for k=1:numel(metrics)
    good=quality.Status=="ok" & isfinite(quality.(metrics{k}));
    values=quality.(metrics{k})(good);
    stats=[NaN NaN NaN NaN];
    if ~isempty(values)
        stats=[mean(values),std(values,0),min(values),max(values)];
    end
    rows(k,:)=[{string(metrics{k}),units(k),height(quality),nnz(good)},num2cell(stats)];
end
summary=cell2table(rows,'VariableNames',{'Metric','Unit','NumImagesRequested', ...
    'NumImagesCompleted','Mean','Std','Min','Max'});
end
