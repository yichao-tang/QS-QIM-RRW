function [layout, selected, sourceIndices] = pcetMomentLayout(nMax)
%PCETMOMENTLAYOUT Reproduce the legacy COMPLEX sortrows moment ordering.
%   Columns are radius, order n, repetition m. In the original code the
%   complex moment values make the entire sorting matrix complex; signed
%   real sortrows would silently assign d_q to different carriers.
[m, n] = ndgrid(-nMax:nMax, -nMax:nMax);
valid = abs(n) + abs(m) <= nMax;
n = n(valid);
m = m(valid);
[sorted, sourceIndices] = sortrows(complex([abs(n + 1i*m), n, m]), [1 2 3]);
layout = real(sorted);
selected = find(mod(layout(:, 3), 4) ~= 0 & layout(:, 3) >= 0);
end
