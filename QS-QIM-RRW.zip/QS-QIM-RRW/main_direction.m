clc;
clear;

%% Parameters setting
directions = {'p30_current','p90','p150'};
Delta = 34.4;              % same Delta; no hidden PSNR recalibration
nMax = 20;
T = 100;
seed_num = 0;
num_images = 100;

%% Images reading (one fixed sample for every legal lattice direction)
root=fileparts(mfilename('fullpath'));
addpath(root);
image_folder=fullfile(root,'image');
p=experiment_parameters();
p.Delta=Delta; p.nMax=nMax; p.T=T; p.WatermarkSeed=seed_num;
p.NumImages=num_images; p.SaveImages=false;
files=select_images(image_folder,num_images,p.SelectionSeed);
parent=fullfile(root,'results','direction');
if ~isfolder(parent), mkdir(parent); end
sweepFolder=tempname(parent); mkdir(sweepFolder);
allResults=cell(numel(directions),1);
tables=cell(numel(directions),1);
for k=1:numel(directions)
    p.Direction=directions{k};
    allResults{k}=run_experiments(files,p,sweepFolder);
    tables{k}=allResults{k}.Summary;
end
summary=vertcat(tables{:});
writetable(summary,fullfile(sweepFolder,'direction_summary.csv'));
save(fullfile(sweepFolder,'direction_results.mat'),'allResults','directions','Delta');
disp(summary);
