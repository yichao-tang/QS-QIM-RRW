function [Iw1, auxiliary] = embedded_main(I, nMax, T, Delta, w, direction)
%EMBEDDED_MAIN Embed the robust watermark using PCET and QS-QIM.
%   I: prepared 512x512 uint8 grayscale image; w: 128 binary bits.
if nargin < 6, direction = 'p30_current'; end
validateattributes(I, {'uint8'}, {'size',[512 512]}, mfilename, 'I');
validateattributes(w, {'numeric','logical'}, {'vector','binary','numel',128});
validateattributes(nMax, {'numeric'}, {'scalar','integer','positive'});
validateattributes(T, {'numeric'}, {'scalar','real','finite','positive'});
validateattributes(Delta, {'numeric'}, {'scalar','real','finite','positive'});
w = double(w(:).');

%% PCET calculation and moment pairing
[~, selected, sourceIndices] = pcetMomentLayout(nMax);
assert(2*numel(w) <= numel(selected), 'QSQIM:MomentCount', ...
    'nMax is too small for 128 watermark bits.');
indices = sourceIndices(selected(1:2*numel(w)));
MMT = PCET_func(I, nMax, indices, false);
M = MMT(3,indices);
A = abs(M*T);
s = reshape(A, 2, []);

%% QS-QIM quantization
s_w = zeros(size(s));
for k = 1:numel(w)
    s_w(:,k) = spheredecodetoMLwi(s(:,k),w(k),Delta,direction);
end
s_w = s_w(:).';
M_w = complex(zeros(size(M)));
nonzero = A ~= 0;
M_w(nonzero) = (abs(s_w(nonzero))./A(nonzero)).*M(nonzero);
M_w(~nonzero) = abs(s_w(~nonzero))/T;

%% Reconstruction and clipping compensation
difference = M_w-M;
d_q = complex(fix(real(difference)*100)/100, ...
    fix(imag(difference)*100)/100);
Ir = pcetDifferenceImage(size(I,1),nMax,d_q);
I_before_clipping = double(I)+round(real(Ir));
Iw1 = uint8(min(255,max(0,I_before_clipping)));
auxiliary = struct('DecimalPlaces',2,'QuantizationErrorComplex',d_q, ...
    'ClippingError',I_before_clipping-double(Iw1), ...
    'ReconstructionUsesPaperTruncation',true);
end
