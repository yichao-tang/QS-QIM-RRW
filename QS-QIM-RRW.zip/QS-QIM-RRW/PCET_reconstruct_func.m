function im_rec = PCET_reconstruct_func(N, Mnm)
%PCET_RECONSTRUCT_FUNC Block-vectorized synthesis using the same PCET basis.
%   Skip zero coefficients and points outside the incircle; bound temporaries.
[X,Y] = meshgrid(-1:(2/(N-1)):1, -1:(2/(N-1)):1);
[theta,r] = cart2pol(X,Y);
pixels = find(r <= 1);
R = r.^2;
active = find(Mnm(4,:) ~= 0);
im_rec = complex(zeros(N));
if isempty(active)
    return
end
orders = 2*pi*real(Mnm(2,active));
repetitions = real(Mnm(3,active));
coefficients = Mnm(4,active);
blockSize = 1024;
for first = 1:blockSize:numel(pixels)
    block = pixels(first:min(first+blockSize-1,numel(pixels)));
    phase = R(block).*orders + theta(block).*repetitions;
    im_rec(block) = sum(exp(1i*phase).*coefficients, 2);
end
end

