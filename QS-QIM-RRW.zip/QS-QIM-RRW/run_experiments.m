function experiment = run_experiments(imageInput, p, outputRoot)
%RUN_EXPERIMENTS Run complete QS-QIM experiments and save per-image evidence.
%   imageInput: image filename, folder, or explicit cell array of filenames.
%   All selected images are retained; failed runs have NaN measurements.
if nargin<2, p=experiment_parameters(); end
if nargin<3, outputRoot=fullfile(fileparts(mfilename('fullpath')),'results'); end
validate_experiment(p);
check_environment();
files=select_images(imageInput,p.NumImages,p.SelectionSeed);
if exist(outputRoot,'dir')~=7, mkdir(outputRoot); end
outputFolder=tempname(outputRoot);
mkdir(outputFolder);
fprintf('Selected %d image(s); Delta=%g, direction=%s\n',numel(files),p.Delta,char(p.Direction));
fprintf('Results: %s\n',outputFolder);

%% Use the same watermark and attack realizations in paired experiments
savedRng=rng;
restoreRng=onCleanup(@() rng(savedRng)); %#ok<NASGU>
rng(p.WatermarkSeed,'twister');
w=double(randi([0 1],1,p.num));
selected=table((1:numel(files)).',string(files),'VariableNames',{'ImageIndex','File'});
writetable(selected,fullfile(outputFolder,'selected_images.csv'));
writematrix(w,fullfile(outputFolder,'watermark.csv'));
imageRows=cell(numel(files),29);
attackTables=cell(numel(files),1);
preprocessing=cell(numel(files),1);
for j=1:numel(files)
    [~,name,ext]=fileparts(files{j});
    imageName=string([name,ext]);
    fprintf('Image %d/%d (%s) ... ',j,numel(files),char(imageName));
    values=num2cell(NaN(1,22));
    status="ok"; message=""; recovered=false;
    try
        [I,preprocessing{j}]=prepare_image(files{j});
        options=p;
        options.AttackSeed=mod(p.AttackSeed+1000*j,2^32-height(p.Attacks));
        if p.SaveImages || p.SaveAttackedImages
            imageFolder=fullfile(outputFolder,sprintf('%03d',j));
            mkdir(imageFolder);
            options.ImageOutputFolder=imageFolder;
        end
        [result,images]=QS_QIM_version(I,p.nMax,p.T,p.Delta,w,options);
        accounting=result.StageInfo.AuxiliaryCoding;
        values={result.PSNR_Iw1,result.PSNR_Ifinal, ...
            result.BER_no_attack_Iw1,result.BER_no_attack, ...
            accounting.DqCodingBits,accounting.DcPositionCodingBits+accounting.DcValueCodingBits, ...
            accounting.SavedLsbBits,accounting.ArithmeticFramingBits+accounting.PacketHeaderBits, ...
            result.StageInfo.PeePayloadBits,result.StageInfo.HashLengthBits, ...
            result.StageInfo.TotalSecondStageBits,result.StageInfo.NumClippedPixels, ...
            result.Timing.RobustEmbedding,result.Timing.ReversibleEmbedding, ...
            result.Timing.WatermarkExtraction,result.Timing.VerificationAndRecovery, ...
            size(I,1),size(I,2),preprocessing{j}.OriginalRows, ...
            preprocessing{j}.OriginalCols,preprocessing{j}.OriginalChannels,nnz(I~=images.I_recovered)};
        % Synthetic/default images use the same file preparation metadata.
        recovered=result.ExactRecovery;
        attackTables{j}=result.AttackResults;
        if p.SaveImages
            imwrite(I,fullfile(imageFolder,'I.png'));
            imwrite(images.Iw1,fullfile(imageFolder,'Iw1.png'));
            imwrite(images.I_final,fullfile(imageFolder,'I_final.png'));
            imwrite(images.I_recovered,fullfile(imageFolder,'I_recovered.png'));
        end
        fprintf('PSNR %.4f dB; BER %.4f%%; auxiliary %d bits; recovery %d\n', ...
            result.PSNR_Ifinal,100*result.BER_no_attack,result.StageInfo.PeePayloadBits,recovered);
    catch failure
        values=num2cell(NaN(1,22));
        recovered=false;
        status="embedding_failed";
        if startsWith(failure.identifier,'QSQIM:Recovery') || ...
                startsWith(failure.identifier,'recoverSecondStageImage:')
            status="recovery_failed";
        end
        message=string(failure.identifier)+": "+string(failure.message);
        attackTables{j}=failedAttacks(p,status,message);
        fprintf('%s: %s\n',char(status),failure.message);
    end
    imageRows(j,:)=[{j,imageName,p.Delta,string(p.Direction),status,recovered},values,{message}];
    prefix=table(repmat(j,height(attackTables{j}),1), ...
        repmat(imageName,height(attackTables{j}),1),'VariableNames',{'ImageIndex','ImageName'});
    attackTables{j}=[prefix,attackTables{j}];
    % Checkpoint after each image, including failures. The MAT is self-contained.
    experiment=assembleExperiment(imageRows(1:j,:),attackTables(1:j),p,w,selected,preprocessing(1:j),outputFolder);
    save(fullfile(outputFolder,'results.mat'),'experiment','-v7');
    writetable(experiment.ImageQuality,fullfile(outputFolder,'image_quality.csv'));
    writetable(experiment.BER,fullfile(outputFolder,'ber.csv'));
end
experiment.Summary=summarize_results(experiment.BER,experiment.ImageQuality,p,numel(files));
experiment.CostSummary=cost_summary(experiment.ImageQuality);
writetable(experiment.Summary,fullfile(outputFolder,'summary.csv'));
writetable(experiment.CostSummary,fullfile(outputFolder,'cost_summary.csv'));
writetable(experiment.ImageQuality(experiment.ImageQuality.Status~="ok",:), ...
    fullfile(outputFolder,'failures.csv'));
experiment.ExcelExported=false;
if p.ExportExcel
    try
        book=fullfile(outputFolder,'results.xlsx');
        writetable(experiment.Summary,book,'Sheet','Summary');
        writetable(experiment.ImageQuality,book,'Sheet','ImageQuality');
        writetable(experiment.BER,book,'Sheet','PerImageBER');
        writetable(experiment.CostSummary,book,'Sheet','CostSummary');
        writetable(selected,book,'Sheet','SelectedImages');
        experiment.ExcelExported=true;
    catch failure
        warning('QSQIM:ExcelExport','CSV/MAT saved, but XLSX export failed: %s',failure.message);
    end
end
save(fullfile(outputFolder,'results.mat'),'experiment','-v7');
fprintf('Complete embedding and recovery: %d/%d; attack failures: %d\n', ...
    nnz(experiment.ImageQuality.ExactRecovery),numel(files),nnz(experiment.BER.Status=="attack_failed"));
end

function experiment=assembleExperiment(rows,attacks,p,w,selected,preprocessing,folder)
names={'ImageIndex','ImageName','Delta','Direction','Status','ExactRecovery', ...
    'PSNR_Iw1_dB','PSNR_Ifinal_dB','NoAttackBER_Iw1','NoAttackBER_Ifinal', ...
    'DqBits','DcBits','BlBits','HeaderAndCodingBits','AuxiliaryBits','HashBits', ...
    'TotalSecondStageBits','ClippedPixels','RobustEmbedding_s','ReversibleEmbedding_s', ...
    'WatermarkExtraction_s','VerificationAndRecovery_s','Rows','Columns', ...
    'SourceRows','SourceColumns','SourceChannels','RecoveryDifferentPixels','ErrorMessage'};
experiment=struct('Parameters',p,'Watermark',w,'SelectedImages',selected, ...
    'Preprocessing',{preprocessing},'ImageQuality',cell2table(rows,'VariableNames',names), ...
    'BER',vertcat(attacks{:}),'OutputFolder',folder,'Complete',height(selected)==size(rows,1), ...
    'Environment',struct('MatlabVersion',version,'MatlabRelease',version('-release'), ...
    'Architecture',computer));
end

function attacks=failedAttacks(p,status,message)
stages="I_final";
if p.CompareStages, stages=["Iw1","I_final"]; end
rows=cell(height(p.Attacks)*numel(stages),10);
n=0;
for k=1:height(p.Attacks)
    for j=1:numel(stages)
        n=n+1;
        rows(n,:)={stages(j),p.Attacks.Condition(k),p.Attacks.Type(k), ...
            p.Attacks.Value(k),NaN,NaN,NaN,NaN,status,message};
    end
end
attacks=cell2table(rows,'VariableNames',{'Stage','Condition','AttackType', ...
    'AttackValue','AttackSeed','BitErrors','BER','BER_Percent','Status','ErrorMessage'});
end
