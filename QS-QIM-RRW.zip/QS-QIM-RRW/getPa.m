function [H, J, d, Gc, directionInfo] = getPa(Delta, directionName)
%GETPA Return the nested-lattice parameters for one legal QCO direction.
%   GETPA(DELTA) preserves the historical p direction with slope
%   sqrt(3)/3. GETPA(DELTA,DIRECTIONNAME) accepts P30_CURRENT, P90, or
%   P150. The three generators use unimodular integer changes of basis, so
%   they generate the same A2 fine lattice. Their first basis vectors are
%   the three legal undirected lattice directions used in the sensitivity
%   experiment.

if nargin < 1 || isempty(Delta)
    Delta = getTi();
end
if nargin < 2 || isempty(directionName)
    directionName = "p30_current";
end
validateattributes(Delta, {'numeric'}, ...
    {'real', 'finite', 'scalar', 'positive'}, mfilename, 'Delta');
directionName = string(validatestring(char(directionName), ...
    {'p30_current', 'p90', 'p150'}, mfilename, 'directionName'));

baseGenerator = [sqrt(3) / 2, 0; 1 / 2, 1];
switch directionName
    case "p30_current"
        changeOfBasis = [1, 0; 0, 1];
        angleDegrees = 30;
    case "p90"
        changeOfBasis = [0, -1; 1, 1];
        angleDegrees = 90;
    case "p150"
        changeOfBasis = [-1, -1; 1, 0];
        angleDegrees = 150;
end

unscaledGenerator = baseGenerator * changeOfBasis;
H = unscaledGenerator * Delta;
J = 2;
d = 2 * Delta;
Gc = J * H;

directionVector = unscaledGenerator(:, 1);
if abs(directionVector(1)) < eps
    directionSlope = Inf;
else
    directionSlope = directionVector(2) / directionVector(1);
end
directionInfo = struct( ...
    'Name', directionName, ...
    'AngleDegrees', angleDegrees, ...
    'Slope', directionSlope, ...
    'DirectionVector', directionVector, ...
    'ChangeOfBasis', changeOfBasis, ...
    'UnscaledGenerator', unscaledGenerator);
end
