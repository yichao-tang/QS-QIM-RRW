%% QS-QIM setup: install the separately distributed arithmetic codec
root = fileparts(mfilename('fullpath'));
addpath(root);
codecFile = installArithmeticCodec();
addpath(fileparts(codecFile));
check_environment();
fprintf('Setup complete. Run main, main_batch, main_delta or main_direction.\n');
